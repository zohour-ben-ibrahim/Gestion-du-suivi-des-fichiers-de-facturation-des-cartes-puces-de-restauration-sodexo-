<?php
error_reporting(E_ERROR);
?>
<html>
<meta charset="iso-8859-1">
<head>
<title>authentification</title>

<script language="JavaScript">

function afficheDate()// Notre fonction pour afficher la date et l'heure   
	{

	jour = new Array ("Dim","Lun","Mar","Mer","Jeu","Ven","Sam");
	mois = new Array ("Jan","F�v","Mar","Avr","Mai","Jui","Jul","Ao�","Sep","/10","Nov","D�c");
	date=new Date();

	datejour=date.getDate();
	heure=date.getHours();
	minute=date.getMinutes();
	seconde=date.getSeconds();
	if (date.getDate()<10) datejour="0"+datejour;

	if (heure<10) heure="0"+heure;
	if (minute<10) minute="0"+minute;
	if (seconde<10) seconde="0"+seconde;
	document.getElementById("texteDate").innerHTML=jour[date.getDay()]+"  "+datejour+"   "+mois[date.getMonth()]+" 			"+heure+":"+minute+":"+seconde;
	setTimeout("afficheDate()", 1000);

		}
</script>
</head>

<body  onload="afficheDate()" background="outils/bg.jpg"><br /><br /><br /><br />
<table width="755" height="544" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#0D6DD3"    style="border-radius: 50px;box-shadow: 8px 8px 12px #004;">
  <tr>
    <td height="51" background="outils/bgr.png"><img src="outils/Sans titre-.png" width="239" height="152" align="right" /></td>
  </tr>
  <tr> <td><div id ="texteDate" style="font-size:10pt;font-weight:bold;"></div></td></tr>
  <tr>
    <td>
	<center><font size="20" color="#88E6FF">Connectez-vous</font></center>
      <form action="outils/verif.php" method="post" enctype="multipart/form-data" name="form1">
	    <table width="280" height="89" border="0" cellspacing="2" cellpadding="7" align="center">
		<tr bgcolor="#3F7BC2">
        <td><b>Matricule:</b></td>
        <td>
         <center><input type="text" name="login" /></center>
        
        </td>
      </tr>
      <tr bgcolor="#3F7BC2">
        <td><b>Mot de passe:</b> </td>
        <td><center><input type="password" name="mtp" /></center></td>
      </tr>
      <tr>
        <td colspan="2"><p align="center"><input type="submit" name="cnx" value="Connexion" /></p></td>
        </tr>
    </table></form></td>
  </tr>
</table>
</body>

</html>
