<?
error_reporting(E_ERROR);
session_start(); 
require_once 't_facture.php';
require_once 'class_nouveau_table.php';
require_once 'pdf.php';
require_once 't_fact.php';
require_once 'C:\xampp\PHPExcel\Classes\PHPExcel\IOFactory.php';
require_once 'C:\xampp\PHPExcel\Classes\PHPExcel\Autoloader.php'; 
require_once 'variables.php';
//récupérer les variables de formulaire
 $m=$_POST['mois'];
 $a=$_POST['annee'];
 $num=$_POST['numfact'];

//On crée une variable contenant le répertoire de destination 
$uploadpath=$uploadpath.$num."\\";


$f=new facture($m,$a,0,$num,$uploadpath);

$nom_t_fact=false; 
$existe=$f->existe();
if ($existe){$nom_t_fact=$f->creer_fact();} //on ne peut pas chercher un champs dans une table inexistante alors il faut tout d'abord verifier son existance
if(($existe) && ($nom_t_fact)){

$path=$uploadpath."tr".$m.$a.".xlsx";
//On déplace le fichier du dossier temporaire vers le dossier de destination 
 $tmp_name=$_FILES['fichier']['tmp_name'];
move_uploaded_file($tmp_name,$path); 
// Chargement du fichier Excel
$objPHPExcel = PHPExcel_IOFactory::load($path);
/**
* récupération de la première feuille du fichier Excel
* @var PHPExcel_Worksheet $sheet
*/

$t= new t_fact($m, $a, $num,$nom_t_fact);


$sheet = $objPHPExcel->getSheet(0);
$i=-1;
// On boucle sur les lignes
foreach($sheet->getRowIterator() as $row) {
   $i=$i+1;
   if($i!=0){
   $j=-1;
   $tab=array();
   // On boucle sur les cellule de la ligne
   foreach ($row->getCellIterator() as $cell) {
      $j=$j+1;
      $x=$cell->getValue();
	  switch ($j) {
    case 0: $tab['id_tr']="'".$x."'";
	break;
	case 1: $tab['mat']="'".$x."'";
	break; 
    case 2: $tab['n_carte']="'".$x."'";
	break;
	case 3: $tab['npre']="'".$x."'";
	break;
	case 4:$x1=str_replace(',','.',$x);
	$tab['mnt']=$x1;
	break;
	case 5:$x=str_replace('\'',' ',$x);// quelques affilié leus libelle contiennent de (')
	$tab['aff']="'".$x."'";
	break;
	case 6: $tab['ville']="'".$x."'";
	break;
	case 7: $tab['date_tr']=" to_date('".$x."', 'YYYY-MM-DD')";
	break;
	
     }}
   $tab['nbr']=$i;
   $t->insertion($tab);
   }}
   $t->valider_transact();
   $r=$t->verif_mnt();
   if($r){
   $res="Validation des calculs terminée avec succes, vous pouvez éffectuer le payement de la facture";
   
   }
   else{
   $res="Validation des calculs terminée, cette facture a besoin de vérification";
   
   }
   //création rapport ______________________________________________________ 
   $pdf = new PDF('l', 'mm', 'A4');

$pdf->AliasNbPages();

$pdf->AddPage();

$pdf->SetDefOrientation('p');
$y= 'Numero de facture: '.$num;
$pdf->SetFont('Arial','',18);
$pdf->Titre3($y);
$x='Mois: '.$m;
$pdf->Titre3($x);
$z='Année: '.$a;
$pdf->Titre3($z);
$pdf->Ln(25);
$pdf->Titre($res);

$nom_fichier="decision.pdf";
$pdf->Output($uploadpath.$nom_fichier,'F');
header("Content-type:application/pdf");
readfile($uploadpath.$nom_fichier);
   
}
else{ if(!$existe){
include 'declaration.php';
	?>
	<head>
	<script language="javascript">window.onload=function(){
    window.setTimeout(function(){
        window.close()
    }, 10);
}</script>

</head>
	<script language="javascript">alert("Cette facture n\'existe pas dans la base !");</script>

	<?
}

else if (!$nom_t_fact){
include 'declaration.php';
	?>
	<head>
	<script language="javascript">window.onload=function(){
    window.setTimeout(function(){
        window.close()
    }, 10);
}</script>

</head>
	<script language="javascript">alert("Cette facture est déja traîtée !");</script>

	<?
}}
?>