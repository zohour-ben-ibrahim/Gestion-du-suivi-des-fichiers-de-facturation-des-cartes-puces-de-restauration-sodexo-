<?
$uploadpath="C:\\xampp\\uploads\\"; //le repertoir d'archivage des rapports et des fichiers facture

$user="zohour"; 
$pass="zohour";//les parametres de connection aà la base
?>