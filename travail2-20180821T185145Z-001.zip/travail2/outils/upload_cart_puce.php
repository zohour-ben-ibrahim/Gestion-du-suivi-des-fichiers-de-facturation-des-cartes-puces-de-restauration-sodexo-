<?php
error_reporting(E_ERROR);
ini_set("memory_limit","-1");
session_start(); 

require_once 'connection.php';
require_once 'C:\xampp\PHPExcel\Classes\PHPExcel\IOFactory.php';
require_once 'C:\xampp\PHPExcel\Classes\PHPExcel\Autoloader.php'; 
require_once 'variables.php';
$a=$_POST['annee'];
$m=$_POST['mois'];
//récupérer les variables de formulaire
//On crée une variable contenant le répertoire de destination 
$uploadpath=$uploadpath."\\charges\\";
//creation de repertoire
if(! is_dir ($uploadpath)){
mkdir($uploadpath);}

//On déplace le fichier du dossier temporaire vers le dossier de destination 
 $tmp_name=$_FILES['fichier']['tmp_name'];
 $path=$uploadpath.$m."_".$a.".xlsx";
move_uploaded_file($tmp_name,$path); 
// Chargement du fichier Excel
$objPHPExcel = PHPExcel_IOFactory::load($path);
/**
* récupération de la première feuille du fichier Excel
* @var PHPExcel_Worksheet $sheet
*/
  $cnx=new connection();
$cnx->Connect("");


$sheet = $objPHPExcel->getSheet(0);


	 $req=$cnx->Select("select max(id) from t_carte_puce");
	  
	 $result=0;
	while($res=$cnx->FetchArray($req)){
	
$id=$res[0];
	}
if($id===null){
$id=0;

}

$i=-1;
// On boucle sur les lignes
foreach($sheet->getRowIterator() as $row) {
   $j=-1;
   $i=$i+1;
   $tab=array();
   // On boucle sur les cellule de la ligne
   foreach ($row->getCellIterator() as $cell) {
      $j=$j+1;
      $x=$cell->getValue();
	  switch ($j) {
    
	case 0: $tab['mat']="'".$x."'";
	 break;
    case 1: $tab['cin']="'".$x."'";
	break;	 
    case 2: $tab['nbr']=$x;
	break;

	case 3:$x=$x=str_replace(',','.',$x);
	$tab['mnt']=$x;
	
	break;
	
     } 
   }
 
 $tab['annee']="'".$a."'";
 $tab['mois']="'".$m."'";
   $tab['id_pos']="'1'";
   $tab['id']=$id;
   $id=$id+1;
  

   $req=$cnx->Insert("t_carte_puce", &$tab, false, false);
   $cnx->Commit();
  

} 


$req=$cnx->Select("select sum(mnt) from t_carte_puce where mois= ".$tab['mois']." and annee=".$tab['annee'] );
	  
	 $result=0;
	while($res=$cnx->FetchArray($req)){
	
$mnt=$res[0];
	}

echo"<script language='javascript'>
alert('Le charge de mois ".$m."/".$a." est ".$mnt." Dinars');
document.location.replace('recup_cp.php');
</script>";
$cnx->__destruct();




?>

  
