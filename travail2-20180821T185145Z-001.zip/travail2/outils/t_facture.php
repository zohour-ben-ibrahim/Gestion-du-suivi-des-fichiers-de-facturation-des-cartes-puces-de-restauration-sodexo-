<?php
error_reporting(E_ERROR);
require_once 'class_nouveau_table.php';
require_once 'connection.php';
class facture {
private $mois;
private $annee;
private $montant;
private $numfact;
private $fichier;
private $conso;
private $glob;
private $b1;
private $b2;
private $b3;
private $b4;
//il faut ajouter b1 ,B2 , b3 et b4 initialiser a vide 

public function __construct($mois, $annee, $montant, $numfact,$uploadpath)                                    
    { $x=func_num_args();
	switch ($x){
	case 5;
	$this->numfact = $numfact;
      $this->mois = $mois;
	  $this->annee = $annee;
	  $this->montant = $montant;
	  $this->b1="";
	  $this->b2="";
	  $this->b3="";
	  $this->b4="";
	$n=new nouveau($this->mois, $this->annee);  
	 
 $this->fichier =$uploadpath.$n->fichier();//retourner nom de fichier sans le créer
 break;
 case 0:
 $this->numfact = "";
      $this->mois = "";
	  $this->annee = "";
	  $this->montant = "";
	  $this->b1="";
	  $this->b2="";
	  $this->b3="";
	  $this->b4="";
 $this->fichier ="";
    }
	}
	
	

//getters


public function getFichier()
{
return $this->fichier;
}

public function getConso()
{
return $this->conso;
}



public function getGlobal()
{
return $this->glob;
}



//fonction retourne false si la facture existe déja, si non elle crée la table t_facture_mm_aaaa et  et retoune son nom
public function creer_fact()
{
$cnx=new connection();
      $cnx->Connect("");
  $req=$cnx->Select("select t_fact from t_facture where mois = ".$this->mois." and annee = ".$this->annee);
	$x=0;
	while($res=$cnx->FetchArray($req)){if($res[0] !="")$x=$x+1;}
	
	if($x === 0){
	
	$n=new nouveau($this->mois, $this->annee);
 //creation de table t_facture_mm_aaaa
 $condition="n_fact ='".$this->numfact."'";
	  
	  $tab= array();
	  $nom_tab="t_facture";
 
$nom_t=$n->facture ();
$tab['t_fact']="'".$nom_t."'";


                 $res1=$cnx->Update($nom_tab,&$tab,$condition,false,false);
 $cnx->Commit(); 
$cnx->__destruct();

	return $nom_t;}//n'existe pas
	else{
	
	return false;
	
	}//existe déja
}

	
public function existe()
{
$cnx=new connection();
      $cnx->Connect("");
  $req=$cnx->Select("select * from t_facture where n_fact = :n and mois = :m and annee = :a",array(":n"=>$this->numfact,":m"=>$this->mois,":a"=>$this->annee));
	$x=0;
	while($res=$cnx->FetchObject($req)){$x=$x+1;}
	$cnx->__destruct();
	if($x === 0)
	return false;//n'existe pas
	else{
	return true;
	
	}//existe déja
}

public function mois_precident_inexistant()//verifier l'existance de la facture de mois précident
{
$m= $this->mois -1;
$cnx=new connection();
      $cnx->Connect("");
	    //verifier si la table t_facture est vide (dans ce cas ca vas retourner faux dans tt les cas
	$req=$cnx->Select("select n_fact from t_facture",false);
	
	$x=0;
	while($res=$cnx->FetchObject($req)){$x=$x+1;}
	  if(($x === 0) && ($m === 0)){//si table t-facture  vide et c la première facture de janvier
	  return true;}
	  else if(($x === 0) && ($m != 0)){return false;}
	 
	  else // tfacture non vide et mois different de 01
	  {$fact_prec=$this->getfact_prec();
  if($fact_prec[0])
	  return true;
	  else
	  return false;
	  
	  }}
	





public function getfact_prec()//retourner la facture de mois précident pour le calcul des balances(encien+nouv)
{
$m=$this->mois-1;
$cnx=new connection();
      $cnx->Connect("");
if($m !=0){

  $req=$cnx->Select("select * from t_facture where annee = :a and mois = :m",array(":a"=>$this->annee,":m"=>$m));
	
	while($res=$cnx->FetchArray($req)){return $res;}
	
	}
	if($m === 0)
	  {
	  $req=$cnx->Select("select * from t_facture where annee = :a and mois = :m",array(":a"=>$this->annee-1,":m"=>12));
	
	while($res=$cnx->FetchArray($req)){return $res;}}
	$cnx->__destruct();
}	

public function getfacture_mois($a,$m)
{
$cnx=new connection();
      $cnx->Connect("");
  $req=$cnx->Select("select * from t_facture where annee = :a and mois = :m",array(":a"=>$a,":m"=>$m));
while($res=$cnx->FetchArray($req))
	{return $res;}
}

public function getfactures($a){
$cnx=new connection();
      $cnx->Connect("");
	  $r=array();
  $req=$cnx->Select("select * from t_facture where annee = :a",array(":a"=>$a));
	while($res=$cnx->FetchArray($req))
	{
	$r[]=$res;}
	return $r;
}




public function insertion()
{$n=new nouveau($this->mois, $this->annee);
 //creation de table global
 if($this->mois === "01")
$this->glob=$n->globale();
else
$this->glob="t_global_".$this->annee;


 //creation de table conso

 $this->conso=$n->conso();


//insertion
$champs= array("n_fact"=>"'".$this->numfact."'", "mois"=>$this->mois, "annee"=>$this->annee, "mnt"=>$this->montant, "fichier"=>"'".$this->fichier."'", "t_conso"=>"'".$this->conso."'", "t_global"=>"'".$this->glob."'", "t_BI"=>"'".$this->b1."'", "t_BII"=>"'".$this->b2."'", "t_BIII"=>"'".$this->b3."'", "t_BVI"=>"'".$this->b4."'");
$cnx=new connection();
$cnx->Connect("");
   $req=$cnx->Insert("t_facture", &$champs, false, false);
   $cnx->Commit();
   $cnx->__destruct();
    

}
public function b_non_calculee ($x){
$cnx=new connection();
      $cnx->Connect("");
	 switch($x){
         case 1:$t="t_BI";
		 break;
		 case 2:$t="t_BII";
		 break;
		 case 3:$t="t_BIII";
		 break;
		 case 4:$t="t_BVI";
		 break;
}	 
  $req=$cnx->Select("select * from t_facture where ".$t." is null",false);
	$y=0;
	while($res=$cnx->FetchArray($req)){$y=$y+1;}
	$cnx->__destruct();
	if($y === 0){
	return false;
	// echo "tt les balances sont calculéé";
	}//tout les balances sont calculée
	else{
	// echo "il ya des balances nn calculé";
	return true;
	}//des balances nn calculée
}

public function balance_non_calculee (){
$cnx=new connection();
      $cnx->Connect("");
	    
  $req=$cnx->Select("select * from t_facture where  t_BI is null or t_BII is null or t_BIII is null or t_BVI is null",false);
	$y=0;
	while($res=$cnx->FetchArray($req)){$y=$y+1;$m=$res[1];$a=$res[2];}
	$cnx->__destruct();
	if($y === 0){
	return false;
	// echo "tt les balances sont calculéé";
	}//tout les balances sont calculée
	else{
	// echo "il ya des balances nn calculé";
	return $m."/".$a;
	}//des balances nn calculée
}



public function derniere_facture (){
$cnx=new connection();
      $cnx->Connect("");
	  $req=$cnx->Select("select * from t_facture  where annee=(select max(annee) from t_facture) order by mois desc",false);
	  $x=0;
	while(($res=$cnx->FetchArray($req)) && ($x<1)){
	$x=$x+1;
	
	return $res;
	
	}
	$cnx->__destruct();
}



public function suprimer_facture ($num){
$cnx=new connection();
      $cnx->Connect("");
	  $req=$cnx->Delete("t_facture",  "where n_fact= :n",array(":n"=>"'".$num."'"),false);
	$cnx->__destruct();
}


public function count_fact(){
$cnx=new connection();
      $cnx->Connect("");
	  $req=$cnx->Select("select count (*) from t_facture",false);
	  
	while($res=$cnx->FetchArray($req)){
	return $res[0];
	}
	$cnx->__destruct();
}


public function creerBalance($x)
{
$cnx=new connection();
      $cnx->Connect("");
	  $n=new nouveau($this->mois, $this->annee);
	  $condition="n_fact= '".$this->numfact."'";
	  
	  $tab= array();
	  $nom_tab="t_facture";
	 switch($x){
         case 1:$this->b1=$n->BI();
		         $tab['t_BI']="'".$this->b1."'";				 
                 $res=$cnx->Update($nom_tab,&$tab,$condition,false,false);
				 $cnx->__destruct();

				 return $this->b1;
		 break;
		 case 2:$this->b2=$n->BII();
		         $tab['t_BII']="'".$this->b2."'";
                 $res=$cnx->Update($nom_tab,$tab,$condition,false,false);
				 $cnx->__destruct();

				 return $this->b2;
    
		 break;
		 case 3:$this->b3=$n->BIII();
		 		 $tab['t_BIII']="'".$this->b3."'";
				 $res=$cnx->Update($nom_tab,$tab,$condition,false,false);
				$cnx->__destruct();
                 return $this->b3;

		 break;
		 case 4:$this->b4=$n->BVI();
		 		 $tab['t_BVI']="'".$this->b4."'";
				 $res=$cnx->Update($nom_tab,$tab,$condition,false,false);
				 $cnx->__destruct();
                 return $this->b4;

		 break;
		 }
}	 



}
?>