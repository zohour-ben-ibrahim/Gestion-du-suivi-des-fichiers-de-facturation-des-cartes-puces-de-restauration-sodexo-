<?php

require_once 'C:\xampp\phpmyadmin\libraries\zip.lib.php' ; // librairie ZIP


//Forcer le téléchargement des fichiers excel--------------------------------------------


$fileName=$_POST['f1'];
$file2Name=$_POST['f2'];
$nom_zip=$_POST['f'];
$zip = new zipfile () ; //on crée une instance zip

// liste des fichiers à compresser
$files = array ( $file2Name, $fileName) ;

$i = 0 ;
while ( count( $files ) > $i )   {

$fo = fopen($files[$i],'r') ; //on ouvre le fichier
$contenu = fread($fo, filesize($files[$i])) ; //on enregistre le contenu
fclose($fo) ; //on ferme fichier

$zip->addfile($contenu, $files[$i]) ; //on ajoute le fichier
$i++; //on incrémente i

}

$archive = $zip->file() ; // on associe l'archive


header('Content-Type: application/x-zip') ; //on détermine les en-tête
header('Content-Disposition: inline; filename='.$nom_zip.'.zip') ;

echo $archive ;

?>