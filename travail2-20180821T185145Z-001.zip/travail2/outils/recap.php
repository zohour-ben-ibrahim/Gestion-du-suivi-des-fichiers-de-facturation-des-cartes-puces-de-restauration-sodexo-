<?
error_reporting(E_ERROR);
session_start();
require_once 't_facture.php';
require_once 'balance.php';
require_once 'rapport_balance.php';
require_once 'variables.php';



$fact= new facture();

//verifier si la table t_facture est vide
$nbr_fact=$fact->count_fact();
$derniere_fature= $fact->derniere_facture ();
if ($nbr_fact === '0'){
    include 'upload.php';
?>
<head>
<script language="javascript">window.onload=function(){
    window.setTimeout(function(){
        window.close()
    }, 10);
}</script>
</head>
	<script language="javascript">alert(" auccune facture dans la base ! ");

</script>
	<?
}
else if (($derniere_fature[5] === null) || ($derniere_fature[6] === null) || ($derniere_fature[6] === null))
{
 include 'upload.php';
	?>
	<head>
	<script language="javascript">window.onload=function(){
    window.setTimeout(function(){
        window.close()
    }, 10);
}</script>

</head>
	<script language="javascript">alert(" veuillez calculer tout les balances puis réessayer ! ");</script>

	<?
}

else
{
//récupérer la dernière facture


//verifier si balance 1 de cette facture est déja traité
$b=$derniere_fature[8];

if($b===null){//le balance n'est pas traité
//creation de table b4
$f=new facture($derniere_fature[1], $derniere_fature[2], $derniere_fature[3], $derniere_fature[0],"");
$tb4=$f->creerBalance(4);
$balance=new balance ();
$balance->initialiser(4);
$balance->inserer(4);


$derniere_fature= $fact->derniere_facture ();  //pour recuperer les champs après mise a jour (ajout de nom de table balance)
$b=$derniere_fature[8];

$r=new rapport($derniere_fature[1],$derniere_fature[2],4,$b,$derniere_fature[0]);
$r->prep_rapport (); 
}
else //si le balance est déja traité on l'affiche 
{

$b4_pdf="b4_".$derniere_fature[1]."_".$derniere_fature[2];
$uploadpath=$uploadpath.$derniere_fature[0]."\\";
header("Content-type:application/pdf");
readfile($uploadpath.$b4_pdf.".pdf");
}



}
?>