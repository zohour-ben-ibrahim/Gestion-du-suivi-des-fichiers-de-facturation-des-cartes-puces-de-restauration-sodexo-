<?
error_reporting(E_ERROR);
session_start();
require_once 't_facture.php';
require_once 'balance.php';
require_once 'rapport_balance.php';
require_once 'variables.php';
$fact= new facture();

//verifier si la table t_facture est vide
$nbr_fact=$fact->count_fact();
$derniere_fature= $fact->derniere_facture ();

if ($derniere_fature[11] === null)
{
 include 'declaration.php';
	?>
	<head>
	<script language="javascript">window.onload=function(){
    window.setTimeout(function(){
        window.close()
    }, 10);
}</script>

</head>
	<script language="javascript">alert(" veuillez uploader la facture ! ");</script>

	<?
}
else{
if ($nbr_fact === '0'){
    include 'upload.php';
	 echo"<script language='javascript'>alert(' auccune facture dans la base ! ');</script>";

}
else
{
//récupérer la dernière facture

$derniere_fature= $fact->derniere_facture ();
//verifier si balance 1 de cette facture est déja traité
$b=$derniere_fature[7];
if($b===null){//le balance n'est pas traité
//creation de table b1
$f=new facture($derniere_fature[1], $derniere_fature[2], $derniere_fature[3], $derniere_fature[0],"");
$tb3=$f->creerBalance(3);
$balance=new balance ();
$balance->initialiser(3);
$balance->inserer(3);

$derniere_fature= $fact->derniere_facture ();  //pour recuperer les champs après mise a jour (ajout de nom de table balance)
$b=$derniere_fature[7];


$r=new rapport($derniere_fature[1],$derniere_fature[2],3,$b,$derniere_fature[0]);
$r->prep_rapport (); 
}
else //si le balance est déja traité on l'affiche 
{
$derniere_fature= $fact->derniere_facture ();
$uploadpath=$uploadpath.$derniere_fature[0]."\\";
$b3_pdf="b3_".$derniere_fature[1]."_".$derniere_fature[2];
header("Content-type:application/pdf");
readfile($uploadpath.$b3_pdf.".pdf");
}



}}
?>