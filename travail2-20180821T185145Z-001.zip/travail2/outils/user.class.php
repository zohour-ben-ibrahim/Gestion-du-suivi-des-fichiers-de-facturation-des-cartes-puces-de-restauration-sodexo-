<?php
//error_reporting(E_ERROR);
	require_once("connection.php");  
  class user {
    private $login=null;
    private $pswd=null;
    function __construct($login, $pswd)
    {
      $this->login = $login;
      $this->pswd = $pswd;
    }
	function exist()
	{
	  $cnx=new connection();
      $cnx->Connect("");
  $cnx->SetFetchMode(OCI_NUM);
  $cnx->SetAutoCommit(true);
   //test existance
   $h = $cnx->Select("select mat from utilisateur where mat = :l and mtp = :m", array(":l"=>$this->login,":m"=>$this->pswd));
  while($r = $cnx->FetchObject($h))
  {
  return $r->MAT;}
$cnx->__destruct();
	}
	
	function getnom ($mat)
	{
	$cnx=new connection();
      $cnx->Connect("");
  $cnx->SetFetchMode(OCI_NUM);
  $cnx->SetAutoCommit(true);
   //test existance
   $h = $cnx->Select("select NOMPRE from t_pers where mat = :m", array(":m"=>$mat));
  while($r = $cnx->FetchObject($h))
  {
  return $r;}
$cnx->__destruct();
	}
	
	}