<?php
error_reporting(E_ERROR);

require_once'pdf.php';
require_once'variables.php';
require_once't_facture.php';
$mois=$_POST['moi'];
$annee=$_POST['annee'];
$rapport=$_POST['rapport'];
$fact=new facture();
$f=$fact->getfacture_mois($annee,$mois);
$numfact=$f[0];
$uploadpath=$uploadpath.$numfact."\\";
$nom_fichier=$uploadpath.$rapport."_".$mois."_".$annee.".pdf";

if (file_exists($nom_fichier)) {
header("Content-type:application/pdf");
readfile($nom_fichier);
} else {
include 'historique.php';
 ?>
<script = "javascript"> alert ("Ce rapport n'est pas encore traité")</script>;
<?php
}
?>