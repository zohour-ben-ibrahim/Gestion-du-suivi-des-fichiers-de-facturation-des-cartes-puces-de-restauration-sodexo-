<?
error_reporting(E_ERROR);
require_once 't_facture.php';
require_once 'connection.php';
require_once'pdf.php';
$annee=$_POST['annee'];
$mat=$_POST['mat'];
$fact=new facture();
$r=$fact->getfactures($annee);
$cnx=new connection();
      $cnx->Connect("");
	  $b1=array();
foreach ($r as $c=>$d){
	$req=$cnx->Select("select * from ".$d[5]." where mat= ".$mat,false);
	while($res=$cnx->FetchArray($req)){
	$res[0]=$d[1]; //remplacer  le champ mat par mois pour l'affichage
	$b1[]=$res;
	} 
}




	  $b2=array();
foreach ($r as $c1=>$d1){
	$req2=$cnx->Select("select * from ".$d1[6]." where mat= ".$mat,false);
	while($res2=$cnx->FetchArray($req2)){
	$res2[0]=$d1[1]; //remplacer  le champ mat par mois pour l'affichage
	$b2[]=$res2;
	}
}



	  $b3=array();
foreach ($r as $c2=>$d2){
	$req3=$cnx->Select("select * from ".$d2[7]." where mat= ".$mat,false);
	while($res3=$cnx->FetchArray($req3)){
	$res3[0]=$d2[1]; //remplacer  le champ mat par mois pour l'affichage
	$b3[]=$res3;
	}
}





	  $b4=array();
foreach ($r as $c3=>$d3){
	$req4=$cnx->Select("select * from ".$d3[8]." where mat= ".$mat,false);
	while($res4=$cnx->FetchArray($req4)){
	$res4[0]=$d3[1]; //remplacer  le champ mat par mois pour l'affichage
	$b4[]=$res4;
	}
}




//recuperer nom et prenom

$req5=$cnx->Select("select NOMPRE from t_pers where mat= ".$mat,false);
	while($res5=$cnx->FetchArray($req5)){
	$nom=$res5[0];
	
	}

	//pour afficher le resultat il faut verifier l'existance de matricule et l'année
	if($nom && $r)
	{
	
	

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

$y= 'Consultation personnalisée: '.$annee;
$pdf->Titre($y);

$p='Matricule: '.$mat;
  $pdf->Titre3($p);
  
	$p1='Nom et prenom: '.$nom;
	$pdf->Titre3($p1);

$tb1='                       CHARGE_POSTE vs CHARGE_SODEXO';
$pdf->Titre2($tb1);	

$h=array("Mois","CHARGE_POSTE","CHARGE_SODEXO","Balance");
	$dimension=array(20, 60, 60,50);
$pdf->BasicTable($h, $b1, $dimension);



$tb2='                       CHARGE_SODEXO vs CONSOMMATION';
$pdf->Titre2($tb2);	

$h=array("Mois","CHARGE_SODEXO","CONSOMMATION","Balance");
	$dimension=array(20, 60, 60,50);
$pdf->BasicTable($h, $b2, $dimension);
	
	

$tb3='                       CHARGE_POSTE vs CONSOMMATION';
$pdf->Titre2($tb3);	

$h=array("Mois","CHARGE_POSTE","CONSOMMATION","Balance");
	$dimension=array(20, 60, 60,50);
$pdf->BasicTable($h, $b3, $dimension);


$tb3='                           Récap';
$pdf->Titre2($tb3);	

$h=array("Mois","CHARGE_POSTE","CHARGE_SODEXO","CONSOMMATION","Balance");
	$dimension=array(20, 50, 50,45,25);
$pdf->BasicTable($h, $b4, $dimension);
	
$pdf->Output();
}
else
{
if(! $nom && $r){
include 'consult.php';
?>
<script language="javascript"> alert ("vouillez verifier le matricule");</script>
<?
}
else if(! $r && $nom){
include 'consult.php';
?>
<script languagee="javascript"> alert ("vouillez verifier l\'année");</script>
<?
}
 else if(! $r && !$nom){
include 'consult.php';
?>
<script languagee="javascript"> alert ("vouillez verifier le matricule et l\'année");</script>
<?
}

}
?>