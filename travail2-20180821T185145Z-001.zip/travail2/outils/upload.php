<?
error_reporting(E_ERROR);
 session_start(); 

if (!isset($_SESSION['pseudo'])){

header('location:../index.php');}
else
{
?>
<html>
<head>
<meta charset="UTF-8">
<title>Upload</title>
 
<script language="JavaScript">
window.onload = montre;
function afficheDate()// Notre fonction pour afficher la date et l'heure   
	{

	jour = new Array ("Dim","Lun","Mar","Mer","Jeu","Ven","Sam");
	mois = new Array ("Jan","Fév","Mar","Avr","Mai","Jui","Jul","Aoû","Sep","/10","Nov","Déc");
	date=new Date();

	datejour=date.getDate();
	heure=date.getHours();
	minute=date.getMinutes();
	seconde=date.getSeconds();
	if (date.getDate()<10) datejour="0"+datejour;

	if (heure<10) heure="0"+heure;
	if (minute<10) minute="0"+minute;
	if (seconde<10) seconde="0"+seconde;
	document.getElementById("texteDate").innerHTML=jour[date.getDay()]+"  "+datejour+"   "+mois[date.getMonth()]+" 			"+heure+":"+minute+":"+seconde;
	setTimeout("afficheDate()", 1000);

		}
			
//fonction destinée à empêcher l'envoie de formulaire en cas d'erreur
function verifForm(f)
{  var numfact =f.numfact.value;
   var montant =f.montant.value;
   var annee =f.annee.selectedIndex;
   var fichier =f.fichier.value;
   var mois = f.mois.selectedIndex;
   var extention1 =fichier.substring(fichier.length - 5);
     var extention2 =fichier.substring(fichier.length - 4);
	 var ext1=".xlsx";
	 var ext2=".xls";
   if((mois>0) && (annee>0) && (montant>0) && !(isNaN(montant)) && (fichier.length!=0) && ((extention1==ext1) || (extention2==ext2)) && (fichier!=null) && (numfact.length>0))
      return true;
   else
   {
      alert("Veuillez remplir correctement tous les champs");
      return false;
   }
}
</script>
<script type="text/javascript" src="menu/stmenu.js"></script>
</head>

<body  onload="afficheDate()" background="bg.jpg"><br /><br /><br /><br />
<table width="755" height="544" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#0D6DD3"    style="border-radius: 50px;box-shadow: 8px 8px 12px #004;">   <tr height="51">
    <td background="banniere.png"><div id ="texteDate" style="font-size:10pt;font-weight:bold;margin-top:135px;"></div></td><td background="banniere.png">	<img src="ban1.gif" width="390" height="152" align="left" onMouseOver="this.src='laposte-tunisie.jpg'" onMouseOut="this.src='ban1.gif'" />
<img src="Sans titre-.png" width="239" height="152" align="right" /></td>
  </tr>
  <tr height="23"><td colspan="2">
	 
	 <script type="text/javascript">
stm_bm(["menu0f4d",980,"","menu/blank.gif",0,"","",1,0,250,0,1000,1,0,0,"","750",67109119,0,1,2,"default","hand","",1,25],this);
stm_bp("p0",[0,4,0,0,0,0,0,0,100,"",-2,"",-2,50,0,0,"#799BD8","transparent","menu/060417line.gif",3,0,0,"#000000","",0,0,0,"transparent","",3,"menu/060417buttona2.gif",26,5,0,"transparent","",3,"",0,0,0,"transparent","",3,"menu/060417buttona1.gif",26,5,0,"transparent","",3,"","","","",20,20,20,20,20,20,20,20]);
stm_ai("p0i0",[0,"Upload","","",-1,-1,0,"","_self","","","","",0,0,0,"","",0,0,0,1,1,"#FFFFF7",1,"#B5BED6",1,"","menu/bg_16.gif",3,3,0,0,"#FFFFF7","#000000","#66FFFF","#000066","bold 7pt Verdana","bold 7pt Verdana",0,0,"","","","",0,0,0],90,26);
stm_bp("p1",[0,4,-2,0,0,0,0,0,100,"progid:DXImageTransform.Microsoft.Fade(overlap=.5,enabled=0,Duration=0.32)",-2,"progid:DXImageTransform.Microsoft.Fade(overlap=.5,enabled=0,Duration=0.32)",-2,78,0,0,"#799BD8","#EEEEEE","menu/060417line1.gif",3,0,0,"#000000"]);
stm_ai("p1i0",[0,"Nouvelle","","",-1,-1,0,"upload.php","_self","","Nouvelle facture","","",0,0,0,"","",0,0,0,1,1,"#FFFFF7",1,"#B5BED6",1,"menu/060417line1.gif","menu/060417line1.gif",3,3,0,0,"#FFFFF7","#000000","#333399","#FF0000","bold 7pt Verdana","bold 7pt Verdana",0,0,"menu/060417line1.gif","menu/060417line1.gif","menu/060417line1.gif","menu/060417line1.gif",10,10,26],65,26);
stm_aix("p1i1","p1i0",[0,"Historique","","",-1,-1,0,"encien.php","_self","","Ancienne facture"],65,26);
stm_ep();
stm_aix("p0i1","p0i0",[0,"Balances","","",-1,-1,0,"","_self","","Balances","","",0,0,0,"","",0,0,0,1,1,"#FFFFF7",1,"#0099CC",0],90,26);
stm_bpx("p2","p1",[0,4,-80]);
stm_aix("p2i0","p1i0",[0,"Balance 1","","",-1,-1,0,"b1.php","_blanc","","Charge poste VS charge SODEXO","","",0,0,0,"","",0,0,0,0],80,26);
stm_aix("p2i1","p2i0",[0,"Balance 2","","",-1,-1,0,"b2.php","_blanc","","Charge Sodexo VS Consommation"],80,26);
stm_aix("p2i2","p2i0",[0,"Balance 3","","",-1,-1,0,"b3.php","_blanc","","Charge poste VS Consommation"],0,26);
stm_aix("p2i3","p2i0",[0,"Récap","","",-1,-1,0,"recap.php","_blanc","","Récap"],0,26);
stm_aix("p2i3","p2i0",[0,"Télécharger balances","","",-1,-1,0,"form_telecharger_balances.php","_self","","Récap"],0,26);
stm_ep();
stm_aix("p0i3","p0i0",[0,"Historique","","",-1,-1,0,"historique.php","_self","","Historique"],90,26);
stm_aix("p0i4","p0i0",[0,"Consultation personnalisée","","",-1,-1,0,"consult.php","_self","","Consultation personnalisée"],90,26);
stm_aix("p0i5","p0i0",[0,"Déclaration","","",-1,-1,0,"declaration.php","_self","","Déclaration"],90,26);
stm_aix("p0i2","p0i0",[0,"Directions","","",-1,-1,0,"residence.php","_self","","Directions","","",0,0,0,"","",0,0,0,1,1,"#FFFFF7",1,"#0066CC"],90,26);
stm_aix("p0i6","p0i0",[0,"Déconnexion","","",-1,-1,0,"logout.php","_self","","Déconnexion"],90,26);
stm_ep();
stm_em();
</script>
	 
	 
	      </td></tr>
		   

		  <tr><td colspan="2">
         <form method="POST" action="recuperer_contenu_fichier.php" enctype="multipart/form-data" onsubmit="return verifForm(this)">
		 <table width="260" height="89" border="0"  cellspacing="2" cellpadding="7" align="center">
		 <tr bgcolor="#3F7BC2">
        <td><b>N° facture: </b></td>
        <td><center><input type="text" name="numfact" width="120" style="width: 120px" /></center></td>
      </tr>
		 <tr bgcolor="#3F7BC2">
        <td><b>Montant: </b></td>
        <td><center><input type="text" name="montant" width="120" style="width: 120px" /></center></td>
      </tr>
		 <tr bgcolor="#3F7BC2"><td><b>Année: </b></td>
        <td>
         <center><select name="annee" width="120" style="width: 120px">
  <option value="0">--Choisir année--</option>
  <option value="2011">2011</option>
  <option value="2012">2012</option>
  <option value="2013">2013</option>
  <option value="2014">2014</option>
</select></center>
        </td>
      </tr>
	  <tr bgcolor="#3F7BC2">
        <td><b>Mois: </b></td>
        <td><center><select name="mois" width="120" style="width: 120px">
  <option value="0">--Choisir mois--</option>
  <option value="01">Janvier</option>
  <option value="02">Février</option>
  <option value="03">Mars</option>
  <option value="04">Avril</option>
  <option value="05">Mai</option>
  <option value="06">Juin</option>
  <option value="07">Juillet</option>
  <option value="08">Août</option>
  <option value="09">Septembre</option>
  <option value="10">Octobre</option>
  <option value="11">Novembre</option>
  <option value="12">Décembre</option>
</select></center></td>
      </tr>
      
	<tr bgcolor="#3F7BC2"><td colspan="2"><input type="file" name="fichier">
<input type="hidden" name="MAX_FILE_SIZE" value="100000"></td></tr> <!--Code pour limiter la taille du fichier-->
<tr><td colspan="2"><center><input type="submit" name="OK" value="Envoyer le fichier"></center></td></tr></table>
</form> 
</td></tr></table>


</body>
</html>
 <?php
 }
?>