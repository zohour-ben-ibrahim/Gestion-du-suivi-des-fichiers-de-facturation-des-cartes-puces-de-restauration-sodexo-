<?
//error_reporting(E_ERROR);
session_start();
$_SESSION['pseudo']=$_POST['login'];

if (!isset($_SESSION['pseudo'])){

header('location:../index.php');}
else
{
?>
<html>
<head>
<meta charset="iso-8859-1">
<title>accueil</title>
 
<script language="JavaScript">
window.onload = montre;
function afficheDate()// Notre fonction pour afficher la date et l'heure   
	{

	jour = new Array ("Dim","Lun","Mar","Mer","Jeu","Ven","Sam");
	mois = new Array ("Jan","F�v","Mar","Avr","Mai","Jui","Jul","Ao�","Sep","/10","Nov","D�c");
	date=new Date();

	datejour=date.getDate();
	heure=date.getHours();
	minute=date.getMinutes();
	seconde=date.getSeconds();
	if (date.getDate()<10) datejour="0"+datejour;

	if (heure<10) heure="0"+heure;
	if (minute<10) minute="0"+minute;
	if (seconde<10) seconde="0"+seconde;
	document.getElementById("texteDate").innerHTML=jour[date.getDay()]+"  "+datejour+"   "+mois[date.getMonth()]+" 			"+heure+":"+minute+":"+seconde;
	setTimeout("afficheDate()", 1000);

		}
			
//fonction destin�e � emp�cher l'envoie de formulaire en cas d'erreur
function verifForm(f)
{
   var annee =f.annee.value;
   var mois = f.mois.selectedIndex;
   if((mois>0) && !(isNaN(annee)) && (annee.length===4))
      return true;
   else
   {
      alert("Veuillez remplir correctement tous les champs");
      return false;
   }
}
</script>
<script type="text/javascript" src="menu/stmenu.js"></script>
</head>

<body  onload="afficheDate()" background="bg.jpg"><br /><br /><br /><br />
<table width="755" height="544" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#0D6DD3"    style="border-radius: 50px;box-shadow: 8px 8px 12px #004;">   <tr height="51">
    <td background="banniere.png"><div id ="texteDate" style="font-size:10pt;font-weight:bold;margin-top:135px;"></div></td><td background="banniere.png">
	<img src="ban1.gif" width="390" height="152" align="left" onMouseOver="this.src='laposte-tunisie.jpg'" onMouseOut="this.src='ban1.gif'" />
	<img src="Sans titre-.png" width="239" height="152" align="right" /></td>
  </tr>
  
   <?php

  require_once 'user.class.php';
  $l=$_POST["login"];
  $m=$_POST["mtp"];
  $u= new user($l,$m);

  $mat=$u->exist();
 if($mat != null)
 {$nom=$u->getnom($mat);
	 echo"<tr height='23'><td colspan='2'>"; ?>
	
	
		 		 <script type="text/javascript">
stm_bm(["menu0f4d",980,"","menu/blank.gif",0,"","",1,0,250,0,1000,1,0,0,"","750",67109119,0,1,2,"default","hand","",1,25],this);
stm_bp("p0",[0,4,0,0,0,0,0,0,100,"",-2,"",-2,50,0,0,"#799BD8","transparent","menu/060417line.gif",3,0,0,"#000000","",0,0,0,"transparent","",3,"menu/060417buttona2.gif",26,5,0,"transparent","",3,"",0,0,0,"transparent","",3,"menu/060417buttona1.gif",26,5,0,"transparent","",3,"","","","",20,20,20,20,20,20,20,20]);
stm_ai("p0i0",[0,"Upload","","",-1,-1,0,"","_self","","","","",0,0,0,"","",0,0,0,1,1,"#FFFFF7",1,"#B5BED6",1,"","menu/bg_16.gif",3,3,0,0,"#FFFFF7","#000000","#66FFFF","#000066","bold 7pt Verdana","bold 7pt Verdana",0,0,"","","","",0,0,0],90,26);
stm_bp("p1",[0,4,-2,0,0,0,0,0,100,"progid:DXImageTransform.Microsoft.Fade(overlap=.5,enabled=0,Duration=0.32)",-2,"progid:DXImageTransform.Microsoft.Fade(overlap=.5,enabled=0,Duration=0.32)",-2,78,0,0,"#799BD8","#EEEEEE","menu/060417line1.gif",3,0,0,"#000000"]);
stm_ai("p1i0",[0,"Nouvelle","","",-1,-1,0,"upload.php","_self","","Nouvelle facture","","",0,0,0,"","",0,0,0,1,1,"#FFFFF7",1,"#B5BED6",1,"menu/060417line1.gif","menu/060417line1.gif",3,3,0,0,"#FFFFF7","#000000","#333399","#FF0000","bold 7pt Verdana","bold 7pt Verdana",0,0,"menu/060417line1.gif","menu/060417line1.gif","menu/060417line1.gif","menu/060417line1.gif",10,10,26],65,26);
stm_aix("p1i1","p1i0",[0,"Historique","","",-1,-1,0,"encien.php","_self","","Ancienne facture"],65,26);
stm_ep();
stm_aix("p0i1","p0i0",[0,"Balances","","",-1,-1,0,"","_self","","Balances","","",0,0,0,"","",0,0,0,1,1,"#FFFFF7",1,"#0099CC",0],90,26);
stm_bpx("p2","p1",[0,4,-80]);
stm_aix("p2i0","p1i0",[0,"Balance 1","","",-1,-1,0,"b1.php","_blanc","","Charge poste VS charge SODEXO","","",0,0,0,"","",0,0,0,0],80,26);
stm_aix("p2i1","p2i0",[0,"Balance 2","","",-1,-1,0,"b2.php","_blanc","","Charge Sodexo VS Consommation"],80,26);
stm_aix("p2i2","p2i0",[0,"Balance 3","","",-1,-1,0,"b3.php","_blanc","","Charge poste VS Consommation"],0,26);
stm_aix("p2i3","p2i0",[0,"R�cap","","",-1,-1,0,"recap.php","_blanc","","R�cap"],0,26);
stm_ep();
stm_aix("p0i3","p0i0",[0,"Historique","","",-1,-1,0,"historique.php","_self","","Historique"],90,26);
stm_aix("p0i4","p0i0",[0,"Consultation personnalis�e","","",-1,-1,0,"consult.php","_self","","Consultation personnalis�e"],90,26);
stm_aix("p0i5","p0i0",[0,"D�claration","","",-1,-1,0,"declaration.php","_self","","D�claration"],90,26);
stm_aix("p0i2","p0i0",[0,"Directions","","",-1,-1,0,"residence.php","_self","","Directions","","",0,0,0,"","",0,0,0,1,1,"#FFFFF7",1,"#0066CC"],90,26);
stm_aix("p0i6","p0i0",[0,"D�connexion","","",-1,-1,0,"logout.php","_self","","D�connexion"],90,26);
stm_ep();
stm_em();
</script>
	
	
	<? echo "</td></tr><tr>
<td width='600' colspan='2'><center><h1><font color='#080A5F'>Bienvenue</br>".$nom->NOMPRE."</font></h1></center></br></br></br>";
}
  else
  
  echo "<tr height='388'><td colspan='2'>
      <form action='verif.php' method='post' enctype='multipart/form-data' name='form1'>
	  <table width='270' height='89' border='0' align='center'><tr>
        <td><b>Matricule :</b></td>
        <td>
          <input type='text' name='login' /><br />
        
        </td>
      </tr>
      <tr>
        <td><b>Mot de passe :</b> </td>
        <td><input type='password' name='mtp' /></td>
      </tr>
      <tr>
        <td colspan='2'><p align='center'><input type='submit' name='cnx' value='Connection' /></br><font color='yellow'>Login/Mot de passe erron�</font></p></td>
        </tr>
    </table></form></td>
  </tr>
</table>
</body>
</html>";}
?>
