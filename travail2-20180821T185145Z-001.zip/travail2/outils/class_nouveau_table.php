<?php
error_reporting(E_ERROR);
require_once 'connection.php'; 

class nouveau {
private $mois;
private $annee;


public function __construct($mois, $annee)                                       
    {
      $this->mois = $mois;
	  $this->annee = $annee;
	  }
	  
function conso ()
{
$nom_table="t_conso_".$this->mois."_".$this->annee;
$req="create table ".$nom_table." (
id_tr varchar2 (20) primary key,
mat varchar2 (5),
cin number (8),
n_carte varchar2 (50),
npre varchar2 (50),
mnt number (20,3),
aff varchar2 (50),
date_tr  varchar2 (50),
type varchar2 (20),
flag varchar2 (5),
constraint conso".$this->mois."_".$this->annee." foreign key (mat) references t_pers (mat))";
$cnx=new connection();
$cnx->Connect(""); 
$x=$cnx->execute($req,false);
$cnx->__destruct();
return $nom_table;
}


function facture ()
{
$nom_table="t_facture_".$this->mois."_".$this->annee;
$req="create table ".$nom_table." (
nbr number (20) primary key,
id_tr varchar2 (20),
mat varchar2 (5),
n_carte varchar2 (50),
npre varchar2 (50),
mnt number (20,3),
aff varchar2 (50),
ville varchar2(50),
date_tr  varchar2(50),
flag varchar2 (5),
rq varchar2 (100),
constraint fact".$this->mois."_".$this->annee." foreign key (mat) references t_pers (mat))";
$cnx=new connection();
$cnx->Connect(""); 
$x=$cnx->execute($req,false);
$cnx->__destruct();
return $nom_table;
}

function globale ()
{
$nom_table="t_global_".$this->annee;
$req="create table ".$nom_table." (
mois number (2),
id_tr varchar2 (20),
mat varchar2 (5),
cin number (8),
n_carte varchar2 (50),
npre varchar2 (50),
mnt number (20,3),
aff varchar2 (20),
date_tr  varchar2 (50),
type varchar2 (20),
constraint pkglob_".$this->annee." primary key (mois,id_tr),
constraint glob".$this->annee." foreign key (mat) references t_pers (mat))";

$cnx=new connection();
$cnx->Connect(""); 
$x=$cnx->execute($req,false);
$cnx->__destruct();
return $nom_table;
}


function BI()
{
$nom_table="t_BI_".$this->mois."_".$this->annee;
$req="create table ".$nom_table." (
mat varchar2 (5) primary key,
charge_poste number(20,3),
charge_sodexo number (20,3),
balance number (20,3),
constraint bI".$this->mois."_".$this->annee." foreign key (mat) references t_pers (mat))";

$cnx=new connection();
$cnx->Connect(""); 
$x=$cnx->execute($req,false);
$cnx->__destruct();
return $nom_table;
}


function BII()
{
$nom_table="t_BII_".$this->mois."_".$this->annee;
$req="create table ".$nom_table." (
mat varchar2 (5) primary key,
charge_sodexo number (20,3),
consommation number(20,3),
balance number (20,3),
constraint bII".$this->mois."_".$this->annee." foreign key (mat) references t_pers (mat))";

$cnx=new connection();
$cnx->Connect(""); 
$x=$cnx->execute($req,false);
$cnx->__destruct();
return $nom_table;
}


function BIII()
{
$nom_table="t_BIII_".$this->mois."_".$this->annee;
$req="create table ".$nom_table." (
mat varchar2 (5) primary key,
charge_poste number (20,3),
consommation number(20,3),
balance number (20,3),
constraint bIII".$this->mois."_".$this->annee." foreign key (mat) references t_pers (mat))";

$cnx=new connection();
$cnx->Connect(""); 
$x=$cnx->execute($req,false);
$cnx->__destruct();
return $nom_table;
}


function BVI()
{
$nom_table="t_BVI_".$this->mois."_".$this->annee;
$req="create table ".$nom_table." (
mat varchar2 (5) primary key,
charge_poste number (20,3),
charge_sodexo number (20,3),
consommation number (20,3),
balance1 number (20,3),
balance2 number (20,3),
balance3 number (20,3),
constraint bVI".$this->mois."_".$this->annee." foreign key (mat) references t_pers (mat))";

$cnx=new connection();
$cnx->Connect(""); 
$x=$cnx->execute($req,false);
$cnx->__destruct();
return $nom_table;
}


function fichier()
{
$nom_fichier="F_".$this->mois."_".$this->annee.".xlsx";
return $nom_fichier;
}



}
?>