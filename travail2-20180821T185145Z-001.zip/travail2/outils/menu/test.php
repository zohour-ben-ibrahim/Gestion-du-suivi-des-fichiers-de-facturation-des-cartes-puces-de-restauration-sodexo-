<?
echo"<script type='text/javascript'>
stm_bm(['menu0f4d',980,'','menu/blank.gif',0,'','',1,0,250,0,1000,1,0,0,'','750',67109119,0,1,2,'default','hand','',1,25],this);
stm_bp('p0',[0,4,0,0,0,0,0,0,100,'',-2,'',-2,50,0,0,'#799BD8','transparent','menu/060417line.gif',3,0,0,'#000000','',0,0,0,'transparent','',3,'menu/060417buttona2.gif',26,5,0,'transparent','',3,'',0,0,0,'transparent','',3,'menu/060417buttona1.gif',26,5,0,'transparent','',3,'','','','',20,20,20,20,20,20,20,20]);
stm_ai('p0i0',[0,'Upload','','',-1,-1,0,'','_self','','','','',0,0,0,'','',0,0,0,1,1,'#FFFFF7',1,'#B5BED6',1,'','menu/bg_16.gif',3,3,0,0,'#FFFFF7','#000000','#66FFFF','#000066','bold 7pt Verdana','bold 7pt Verdana',0,0,'','','','',0,0,0],90,26);
stm_bp('p1',[0,4,-2,0,0,0,0,0,100,'progid:DXImageTransform.Microsoft.Fade(overlap=.5,enabled=0,Duration=0.32)',-2,'progid:DXImageTransform.Microsoft.Fade(overlap=.5,enabled=0,Duration=0.32)',-2,78,0,0,'#799BD8','#EEEEEE','menu/060417line1.gif',3,0,0,'#000000']);
stm_ai('p1i0',[0,'Nouvelle','','',-1,-1,0,'upload.php','_self','','Nouvelle facture','','',0,0,0,'','',0,0,0,1,1,'#FFFFF7',1,'#B5BED6',1,'menu/060417line1.gif','menu/060417line1.gif',3,3,0,0,'#FFFFF7','#000000','#333399','#FF0000','bold 7pt Verdana','bold 7pt Verdana',0,0,'menu/060417line1.gif','menu/060417line1.gif','menu/060417line1.gif','menu/060417line1.gif',10,10,26],65,26);
stm_aix('p1i1','p1i0',[0,'Historique','','',-1,-1,0,'encien.php','_self','','Ancienne facture'],65,26);
stm_ep();
stm_aix('p0i1','p0i0',[0,'Balances','','',-1,-1,0,'','_self','','Balances','','',0,0,0,'','',0,0,0,1,1,'#FFFFF7',1,'#0099CC',0],90,26);
stm_bpx('p2','p1',[0,4,-80]);
stm_aix('p2i0','p1i0',[0,'Balance 1','','',-1,-1,0,'b1.php','_blanc','','Charge poste VS charge SODEXO','','',0,0,0,'','',0,0,0,0],80,26);
stm_aix('p2i1','p2i0',[0,'Balance 2','','',-1,-1,0,'b2.php','_blanc','','Charge Sodexo VS Consommation'],80,26);
stm_aix('p2i2','p2i0',[0,'Balance 3','','',-1,-1,0,'b3.php','_blanc','','Charge poste VS Consommation'],0,26);
stm_aix('p2i3','p2i0',[0,'R�cap','','',-1,-1,0,'recap.php','_blanc','','R�cap'],0,26);
stm_ep();
stm_aix('p0i2','p0i0',[0,'Rapport','','',-1,-1,0,'rapport.php','_blanc','','Rapport','','',0,0,0,'','',0,0,0,1,1,'#FFFFF7',1,'#0066CC'],90,26);
stm_aix('p0i3','p0i0',[0,'Historique','','',-1,-1,0,'historique.php','_self','','Historique'],90,26);
stm_aix('p0i4','p0i0',[0,'Consultation personnalis�e','','',-1,-1,0,'consult.php','_self','','Consultation personnalis�e'],90,26);
stm_aix('p0i5','p0i0',[0,'D�claration','','',-1,-1,0,'','_self','','D�claration'],90,26);
stm_aix('p0i6','p0i0',[0,'D�connexion','','',-1,-1,0,'logout.php','_self','','D�connexion'],90,26);
stm_ep();
stm_em();
</script>";

?>