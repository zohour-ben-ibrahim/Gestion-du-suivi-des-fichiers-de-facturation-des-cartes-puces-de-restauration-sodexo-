<?
error_reporting(E_ERROR);
session_start(); 

if (!isset($_SESSION['pseudo'])){

header('location:../index.php');}
else
 {
require_once 't_facture.php';
require_once 'connection.php';
require_once 'excelwriter.inc.php';
require_once 'C:\xampp\phpmyadmin\libraries\zip.lib.php' ; // librairie ZIP

include('variables.php');

$mois=$_POST['mois'];
$annee=$_POST['annee'];
	$cnx=new connection();
      $cnx->Connect("");
	 $f=new facture();
$fact=$f->getfacture_mois($annee,$mois);	
if(($fact[0]===null) || ($fact[4]===null)|| ($fact[5]===null)|| ($fact[6]===null)|| ($fact[7]===null)){
?>
<script language="javascript">
alert("vérifiez le mois et l'année !");
document.location.replace("form_telecharger_balances.php");
</script>;
<?
}
else{
$uploadpath=$uploadpath."\\".$fact[0]."\\balances\\"; 
  if(! is_dir ($uploadpath)){
mkdir($uploadpath);}
$fileName1 = $uploadpath."BI_".$fact[1]."_".$fact[2].".xls";
	$excel = new ExcelWriter($fileName1);
	$myArr=array("Matricule",
	            "cin",
				"Nom et prenom",
				"Charge poste",
				"Charge SODEXO",
				"Balance"
				);

	$excel->writeLine($myArr, array('text-align'=>'center', 'color'=> 'blue', 'font'=>'bold'));

       
	$req=$cnx->Select("select b.mat, p.nompre, p.cin, b.CHARGE_POSTE, b.CHARGE_SODEXO, b.BALANCE from t_pers p,".$fact[5]." b
  where b.mat = p.mat");
	
	
	while($res=$cnx->FetchArray($req)){
      $tab=array ($res[0],$res[1],$res[2],$res[3],$res[4], $res[5]);
	$excel->writeLine($tab, array('text-align'=>'left', 'color'=> 'black'));
}
	
	 
	$excel->close();
	
	
	
	
	//balance2_________________________________________________________________
	
	
	
	$fileName2 = $uploadpath."BII_".$fact[1]."_".$fact[2].".xls";
	$excel = new ExcelWriter($fileName2);
	$myArr=array("Matricule",
	            "cin",
				"Nom et prenom",
				"Charge SODEXO",
				"Consommation",
				"Balance"
				);

	$excel->writeLine($myArr, array('text-align'=>'center', 'color'=> 'blue', 'font'=>'bold'));

       
	$req=$cnx->Select("select b.mat, p.nompre, p.cin, b.CHARGE_SODEXO, b.CONSOMMATION, b.BALANCE from t_pers p,".$fact[6]." b
  where b.mat=p.mat",false);
	
	
	while($res=$cnx->FetchArray($req)){
      $tab=array ($res[0],$res[1],$res[2],$res[3],$res[4], $res[5]);
	$excel->writeLine($tab, array('text-align'=>'left', 'color'=> 'black'));
}
	
	 
	$excel->close();
	
	
	
	
	//balance3________________________________________________________________
	
	
	$fileName3 = $uploadpath."BIII_".$fact[1]."_".$fact[2].".xls";
	$excel = new ExcelWriter($fileName3);
	$myArr=array("Matricule",
	            "cin",
				"Nom et prenom",
				"Charge poste",
				"consommation",
				"Balance"
				);

	$excel->writeLine($myArr, array('text-align'=>'center', 'color'=> 'blue', 'font'=>'bold'));

       
	$req=$cnx->Select("select b.mat, p.nompre, p.cin, b.CHARGE_POSTE, b.consommation, b.BALANCE from  t_pers p,".$fact[7]." b
  where b.mat=p.mat",false);
	
	
	while($res=$cnx->FetchArray($req)){
      $tab=array ($res[0],$res[1],$res[2],$res[3],$res[4], $res[5]);
	$excel->writeLine($tab, array('text-align'=>'left', 'color'=> 'black'));
}
	
	 
	$excel->close();
	
	
	//balance4_________________________________________________________________
	
	$fileName4 = $uploadpath."BIV_".$fact[1]."_".$fact[2].".xls";
	$excel = new ExcelWriter($fileName4);
	$myArr=array("Matricule",
	            "cin",
				"Nom et prenom",
				"Charge poste",
				"Charge SODEXO",
				"consommation",
				"Balance1",
				"Balance2",
				"Balance3"
				);

	$excel->writeLine($myArr, array('text-align'=>'center', 'color'=> 'blue', 'font'=>'bold'));

       
	$req=$cnx->Select("select b.mat,  p.cin,p.nompre, b.CHARGE_POSTE, b.CHARGE_SODEXO, b.consommation, b.BALANCE1, b.BALANCE2, b.BALANCE3 from t_pers p,".$fact[8]." b
  where b.mat=p.mat",false);
	
	
	while($res=$cnx->FetchArray($req)){
      $tab=array ($res[0],$res[1],$res[2],$res[3],$res[4], $res[5],$res[6],$res[7],$res[8]);
	$excel->writeLine($tab, array('text-align'=>'left', 'color'=> 'black'));
}
	
	 
	$excel->close();
	
	
	
	
//compression et telechargement___________________________________

$zip = new zipfile () ; //on crée une instance zip

// liste des fichiers à compresser
$files = array ( $fileName1,$fileName2,$fileName3,$fileName4) ;

$i = 0 ;
while ( count( $files ) > $i )   {

$fo = fopen($files[$i],'r') ; //on ouvre le fichier
$contenu = fread($fo, filesize($files[$i])) ; //on enregistre le contenu
fclose($fo) ; //on ferme fichier

$zip->addfile($contenu, $files[$i]) ; //on ajoute le fichier
$i++; //on incrémente i

}

$archive = $zip->file() ; // on associe l'archive
$nom_zip="Balances_".$mois."_".$annee;

header('Content-Type: application/x-zip') ; //on détermine les en-tête
header('Content-Disposition: inline; filename='.$nom_zip.'.zip') ;

echo $archive ;
}
}
