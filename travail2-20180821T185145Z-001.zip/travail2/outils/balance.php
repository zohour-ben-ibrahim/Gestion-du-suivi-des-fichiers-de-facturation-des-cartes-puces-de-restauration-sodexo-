<?php
error_reporting(E_ERROR);
require_once 'connection.php';
require_once 't_facture.php';
class balance{
private $facture;
//la facture sur la quelle on va travailler

function __construct(){
$f= new facture();
$this->facture=$f->derniere_facture ();

}


function verif_b_prec ()
{$f= new facture();
$count=$f->count_fact();

}


function  initialiser($x){
$fact=$this->facture;
$cnx=new connection();
      $cnx->Connect("");
if ($fact[1] === '1'){
     $t=array();
	 
	  $req=$cnx->Select("select distinct mat from ".$fact[9]." where upper(flag)= 'OK' or flag is NULL");  // <> none
	  while($res=$cnx->FetchArray($req)){
	
	     switch($x){
              case 1:$t['mat']=$res[0];
			         $t['charge_poste']=0;
					 $t['charge_sodexo']=0;
					  $req1=$cnx->Insert($fact[5], &$t, false, false);
                      
		      break;
		      case 2:$t['mat']=$res[0];
			         $t['consommation']=0;
					 $t['charge_sodexo']=0;
					 $req1=$cnx->Insert($fact[6], &$t, false, false);
		      break;
		      case 3:$t['mat']=$res[0];
			         $t['consommation']=0;
					 $t['charge_poste']=0;
					 $req1=$cnx->Insert($fact[7], &$t, false, false);
		      break;
		      case 4:$t['mat']=$res[0];
			         $t['consommation']=0;
					 $t['charge_poste']=0;
					  $t['charge_sodexo']=0;
					  $req1=$cnx->Insert($fact[8], &$t, false, false);
		      break;
	
	
	        }
        }
    $cnx->__destruct();
    $cnx->Commit();

    }
	else{
	
	$f=new facture($fact[1], $fact[2], $fact[3], $fact[0],"");
    $f_prec=$f->getfact_prec();
	$t=array();
	 
	 
	
	     switch($x){
              case 1: $req=$cnx->Select("select * from ".$f_prec[5]);
	                  while($res=$cnx->FetchArray($req)){
			              $t['mat']=$res[0];
						  $r1=str_replace(',','.',$res[1]);
			              $t['charge_poste']=$r1;
						  $r2=str_replace(',','.',$res[2]);
					      $t['charge_sodexo']=$r2;
					      $req1=$cnx->Insert($fact[5], &$t, false, false);
                        }
						//ajouter les nouveau matricules qui n'apparaissent pas des les factures precedentes
		             $req2=$cnx->Select("select distinct mat from ".$fact[9]." where (upper(flag)= 'OK' or flag is NULL) and mat not in (select mat from ".$f_prec[5].")");
					 $t1=array();
	                 while($res1=$cnx->FetchArray($req2)){
					 $t1['mat']=$res1[0];
					 $t1['charge_poste']=0;
					 
					 $t1['charge_sodexo']=0;
					 $req3=$cnx->Insert($fact[5], &$t1, false, false);
	     }
		      break;
		      case 2: $req=$cnx->Select("select * from ".$f_prec[6]);
	                  while($res=$cnx->FetchArray($req)){
					 $t['mat']=$res[0];
					 $r2=str_replace(',','.',$res[2]);
			         $t['consommation']=$r2;
					 $r1=str_replace(',','.',$res[1]);					 
					 $t['charge_sodexo']=$r1;
					 $req1=$cnx->Insert($fact[6], &$t, false, false);
					 }
					 //ajouter les nouveau matricules qui n'apparaissent pas des les factures precedentes
		             $req2=$cnx->Select("select distinct mat from ".$fact[9]." where (upper(flag)= 'OK' or flag is NULL) and mat not in (select mat from ".$f_prec[6].")");
	                 while($res1=$cnx->FetchArray($req2)){
					 $t1['mat']=$res1[0];
			         $t1['consommation']=0;
					 $t1['charge_sodexo']=0;
					 $req3=$cnx->Insert($fact[6], &$t1, false, false);
	     }
		      break;
		      case 3: $req=$cnx->Select("select * from ".$f_prec[7]);
	                  while($res=$cnx->FetchArray($req)){
					  $t['mat']=$res[0];
					  $r2=str_replace(',','.',$res[2]);
			          $t['consommation']=$r2;
					  $r1=str_replace(',','.',$res[1]);
					  $t['charge_poste']=$r1;
					  $req1=$cnx->Insert($fact[7], &$t, false, false);
					 }
					 //ajouter les nouveau matricules qui n'apparaissent pas des les factures precedentes
		             $req2=$cnx->Select("select distinct mat from ".$fact[9]." where (upper(flag)= 'OK' or flag is NULL) and mat not in (select mat from ".$f_prec[7].")");
	                 while($res1=$cnx->FetchArray($req2)){
					 $t1['mat']=$res1[0];
			         $t1['consommation']=0;
					 $t1['charge_poste']=0;
					 $req3=$cnx->Insert($fact[7], &$t1, false, false);
	     }
		      break;
		      case 4: $req=$cnx->Select("select * from ".$f_prec[8]);
	                  while($res=$cnx->FetchArray($req)){
					  $t['mat']=$res[0];
					  $r3=str_replace(',','.',$res[3]);
			          $t['consommation']=$r3;
					  $r1=str_replace(',','.',$res[1]);
					  $t['charge_poste']=$r1;
					  $r2=str_replace(',','.',$res[2]);
					  $t['charge_sodexo']=$r2;
					  $req1=$cnx->Insert($fact[8], &$t, false, false);
					  }
					  //ajouter les nouveau matricules qui n'apparaissent pas des les factures precedentes
		             $req2=$cnx->Select("select distinct mat from ".$fact[9]." where (upper(flag)= 'OK' or flag is NULL) and mat not in (select mat from ".$f_prec[8].")");
	                 while($res1=$cnx->FetchArray($req2)){
					 $t1['mat']=$res1[0];
			         $t1['consommation']=0;
					 $t1['charge_poste']=0;
					 $t1['charge_sodexo']=0;
					 $req3=$cnx->Insert($fact[8], &$t1, false, false);
	     }
		      break;
	
	
	        
        }
		
	$cnx->Commit();	
    $cnx->__destruct();
    
	
	}
}	





function conso ($mat) {

$fact=$this->facture;

$cnx=new connection();
      $cnx->Connect("");
	   // $req1=$cnx->Select("select cin from t_pers  where mat = ".$mat,false);
		// while($res1=$cnx->FetchArray($req1)){$cin=$res1[0];} //en cas ou un agent a ++ mat on utilise le cin 
		// $complement_condition="";
		// if ($cin){$complement_condition="or cin= ".$cin;}
	 $req=$cnx->Select("select sum(MNT) from ".$fact[9]." t where upper (t.type)='ACHAT' and  MAT= :m  and upper (flag)= 'OK'",array(":m"=>$mat));
	  $conso=0;
	while ($res=$cnx->FetchArray($req)){
	$c= $res[0] ;
	}
	if ($c)
	$conso=$c;
//j ai annulé le calcul des annulation car les opérations annulées n'auront pas le flag ='OK'
	// $req1=$cnx->Select("select sum(MNT) from ".$fact[9]." t  where upper (t.type)='ANNULATION' and ( MAT= :m ".$complement_condition." )",array(":m"=>$mat));
	  
	 // $annul=0;
	while ($res1=$cnx->FetchArray($req1)){
	$a= $res1[0];
	}
	$cnx->__destruct();
	if($a)
	$annul=$a;
	
	$result=$conso;
	
	//-$annul;
	return $result;

}





function charge_SDX($mat){
$fact=$this->facture;

$cnx=new connection();
      $cnx->Connect("");
	 
	  $req=$cnx->Select("select sum (mnt) from ".$fact[9]." t where upper (t.type)='RECHARGEMENT' and  MAT= :m ",array(":m"=>$mat));
	 
	 $result=0;
	while($res=$cnx->FetchArray($req)){
	
$r=$res[0];
	}
	$cnx->__destruct();
	if ($r)
	return $r;
	else
	return $result;
	
}


function charge_POSTE($mat){
$fact=$this->facture;
$cnx=new connection();
      $cnx->Connect("");
	 $req=$cnx->Select("select sum (nbr)*4.45 from t_carte_puce  where mois= :mo and annee= :a and mat= :m  and id_pos='1'",array(":mo"=>$fact[1],":a"=>$fact[2],":m"=>$mat));
	  
	 $result=0;
	while($res=$cnx->FetchArray($req)){
	
$r=$res[0];
	}
	$cnx->__destruct();
	if ($r)
	return $r;
	else
	return $result;
}



function balances ($mat){
$fact=$this->facture;
$cnx=new connection();
      $cnx->Connect("");
$req=$cnx->Select("select b1.balance, b2.balance, b3.balance from ".$fact[5]." b1 , ".$fact[6]." b2 , ".$fact[7]." b3 where b1.mat = ".$mat." and b1.mat =b2.mat and b1.mat = b3.mat");
	                  while($res=$cnx->FetchArray($req)){
					  return $res;}
					  $cnx->__destruct();
}

//______________________________________________________________________

function inserer ($x) {
$fact=$this->facture;
$cnx=new connection();
      $cnx->Connect("");
$t=array();
	 
	 
	
	     switch($x){
              case 1: $req=$cnx->Select("select mat from ".$fact[5]);
	                  while ($res=$cnx->FetchArray($req)){
			              $mat=$res[0];
						  $ps=$this->charge_POSTE($mat);
						  $p=str_replace(',','.',$ps);
						  $sd=$this->charge_SDX($mat);
						  $s=str_replace(',','.',$sd);
			              $t['charge_poste']="charge_poste +".$p;
					      $t['charge_sodexo']="charge_sodexo +".$s;
						  $tb['balance']="charge_poste - charge_sodexo";						  
						  //mise à jour
						   $condition="mat= ".$mat;
						   $res1=$cnx->Update ($fact[5],&$t,$condition,false,false);
						   $res1=$cnx->Update ($fact[5],&$tb,$condition,false,false);
                        }
						   
                           
		      break;
		      case 2: $req=$cnx->Select("select mat from ".$fact[6]);
	                  while($res=$cnx->FetchArray($req)){
			              $mat=$res[0];
						   $sd=$this->charge_SDX($mat);
						  $s=str_replace(',','.',$sd);
						  $cs=$this->conso($mat);
						  $c=str_replace(',','.',$cs);
			              $t['consommation']="consommation +".$c;
					      $t['charge_sodexo']="charge_sodexo +".$s;
						  $tb['balance']="charge_sodexo - consommation";
						  //mise à jour
						   $condition="mat= ".$mat;
						   $res1=$cnx->Update ($fact[6],&$t,$condition,false,false);
                           $res1=$cnx->Update ($fact[6],&$tb,$condition,false,false);   
					 }
					  

		      break;
		      case 3: $req=$cnx->Select("select mat from ".$fact[7]);
	                  while($res=$cnx->FetchArray($req)){
			              $mat=$res[0];
						  $ps=$this->charge_POSTE($mat);
						  $p=str_replace(',','.',$ps);
						  $cs=$this->conso($mat);
						  $c=str_replace(',','.',$cs);
			              $t['charge_poste']="charge_poste +".$p;
					      $t['consommation']="consommation +".$c;
						  $tb['balance']="charge_poste - consommation";
						  //mise à jour
						   $condition="mat= ".$mat;
						   $res1=$cnx->Update ($fact[7],&$t,$condition,false,false);
						   $res1=$cnx->Update ($fact[7],&$tb,$condition,false,false);
					 }
					 
		      break;
		      case 4: $req=$cnx->Select("select mat from ".$fact[8]);
	                  while($res=$cnx->FetchArray($req)){
			              $mat=$res[0];
						  $ps=$this->charge_POSTE($mat);
						  $p=str_replace(',','.',$ps);
						  $sd=$this->charge_SDX($mat);
						  $s=str_replace(',','.',$sd);
						  $cs=$this->conso($mat);
						  $c=str_replace(',','.',$cs);
						  $b=$this->balances($mat);
						  $b1=str_replace(',','.',$b[0]);
						  $b2=str_replace(',','.',$b[1]);
						  $b3=str_replace(',','.',$b[2]);
			              $t['consommation']="consommation +".$c;
			              $t['charge_poste']="charge_poste +".$p;
					      $t['charge_sodexo']="charge_sodexo +".$s;
						  $t['balance1']=$b1;
						  $t['balance2']=$b2;
						  $t['balance3']=$b3;
						  //mise à jour
						   $condition="mat= ".$mat;
						   $res1=$cnx->Update ($fact[8],&$t,$condition,false,false);
						   
					  }
		      break;
	
	
	        
        }
	$cnx->Commit();	
    $cnx->__destruct();
    



}


}

