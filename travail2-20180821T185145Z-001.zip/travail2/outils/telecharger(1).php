<html>
<head></head>
<body>

<form method="POST" action="recuperer_contenu_fichier.php" enctype="multipart/form-data">	
  <center></br></br></br><font color="#14165F" size="5"><b> Fichier :     </b><input type="file" name="fichier"></font>
   
<input type="hidden" name="MAX_FILE_SIZE" value="100000"></br></br></br> <!--Code pour limiter la taille du fichier-->
<input type="submit" name="OK" value="Envoyer le fichier"></center>
</form> 

<?php
if(! empty($_FILES['fichier']) && $_FILES['fichier']['error'] == UPLOAD_ERR_OK && is_uploaded_file($_FILES['fichier']['tmp_name']))
{
  $file = $_FILES['fichier']['tmp_name'];   // Le fichier téléversé
  $dest = '/' . $_FILES['fichier']['name']; // Sa destination
  }
if(isset($_FILES['avatar']))
{ 
     $dossier = 'upload/';
     $fichier = basename($_FILES['avatar']['name']);
     if(move_uploaded_file($_FILES['avatar']['tmp_name'], $dossier . $fichier)) //Si la fonction renvoie TRUE, c'est que ça a fonctionné...
     {
          echo 'Upload effectué avec succès ';
     }
     else //Sinon (la fonction renvoie FALSE).
     {
          echo 'Echec de l\'upload !';
     }
}
?>
</body>
</html>