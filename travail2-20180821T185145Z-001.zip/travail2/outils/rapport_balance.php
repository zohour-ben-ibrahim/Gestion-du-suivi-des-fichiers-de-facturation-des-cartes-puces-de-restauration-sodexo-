<?php 
error_reporting(E_ERROR);

require_once 'connection.php'; 
require_once'pdf.php';

class rapport{
private $moi;
private $annee;
private $num_balance;//1 ou 2 ou 3 ou 4
private $table;
private $numfact;

function __construct ( $moi, $annee, $num_balance, $table, $numfact){
$this->moi=$moi;
$this->annee=$annee;
$this->num_balance=$num_balance;
$this->table=$table;
$this->numfact=$numfact;
}


function champs () {
$cnx=new connection();
      $cnx->Connect("");
	  $r= array();
	  $req=$cnx->Select("Select column_name from user_tab_cols where table_name=upper('".$this->table."')",false);
      while($res=$cnx->FetchArray($req)) {
	  if ($res[0]){
	   $r[]=$res[0];}
}
 $cnx->__destruct();
return $r;
}


function liste_negatif(){
$cnx=new connection();
      $cnx->Connect("");
	 $r=false;
	 $t=array();
	  $req=$cnx->Select("select * from ".$this->table." where balance<0",false);
	while($res=$cnx->FetchArray($req)) {
	$r=true;
	$t[]=$res;
}
 $cnx->__destruct();
if ($r)
return $t;
else
return $r;
}



function liste(){
$cnx=new connection();
      $cnx->Connect("");
	 $r=false;
	 $t=array();
	  $req=$cnx->Select("select * from ".$this->table,false);
	while($res=$cnx->FetchArray($req)) {
	$r=true;
	$t[]=$res;
}
 $cnx->__destruct();
if ($r)
return $t;
else
return $r;
}




function mnt_positif () {
$cnx=new connection();
      $cnx->Connect("");
	  $req=$cnx->Select("select sum(balance) from ".$this->table." where balance>0",false);
	while($res=$cnx->FetchArray($req)) {
	return $res[0];
}
 $cnx->__destruct();
}




function mnt_negatif(){
$cnx=new connection();
      $cnx->Connect("");
	  $req=$cnx->Select("select sum(balance) from ".$this->table." where balance<0",false);
	while($res=$cnx->FetchArray($req)) {
	$p=str_replace(',','.',$res[0]);
	 $r=(float)$p * -1;
}
 $cnx->__destruct();
 return $r;
}



function nbr_positif () {
$cnx=new connection();
      $cnx->Connect("");
	  $req=$cnx->Select("select count(*) from ".$this->table." where balance>0",false);
	while($res=$cnx->FetchArray($req)) {
	return $res[0];
}
 $cnx->__destruct();
}
function nbr_null(){
$cnx=new connection();
      $cnx->Connect("");
	  $req=$cnx->Select("select count(*) from ".$this->table." where balance=0",false);
	while($res=$cnx->FetchArray($req)) {
	return $res[0];
}
 $cnx->__destruct();
}

function nbr_negatif(){
$cnx=new connection();
      $cnx->Connect("");
	  $req=$cnx->Select("select count(*) from ".$this->table." where balance<0",false);
	while($res=$cnx->FetchArray($req)) {
	return $res[0];
}
 $cnx->__destruct();
}




function prep_rapport (){



$pdf = new PDF('l', 'mm', 'A4');

$pdf->AliasNbPages();

$pdf->AddPage();
if($this->num_balance=== 4){
$pdf->SetDefOrientation('p');
$y= 'Balance Récapitulatif ';
$pdf->Titre($y);
	$dimension3=array(28, 45, 45, 45, 38, 38, 38);
    $h3=$this->champs();
	$res3=$this->liste();
	$pdf->BasicTable($h3, $res3, $dimension3);
}
else
{
$y=$this->champs();
$pdf->Titre($y[1].' VS '.$y[2]);

$z=$this->moi."/".$this->annee;
$pdf->Titre($z);

$x='Facture: '.$this->numfact;
//$pdf->Titre3();
$pdf->Ln(5);
//couleur de texte
    $pdf->SetTextColor(60,60,120);
       //couleur de contour
   $pdf->SetDrawColor(0,80,180);
       // Couleur de fond
    $pdf->SetFillColor(255,255,255);
$pdf->Cell(0,10,$x,0,1);

$pdf->Titre2("Balance (+)");
	$h=array("nombre","Montant");
	$res=array();
	$r[]=$this->nbr_positif();
	$r[]=$this->mnt_positif();
	$res=array();
	$res[]=$r;
	$dimension=array( 60, 60);
$pdf->BasicTable($h, $res, $dimension);


$pdf->Titre2("Balance (0)");
	$h1=array("nombre");
	$res1=array();
	$r1[]=$this->nbr_null();
	$res1=array();
	$res1[]=$r1;
	$dimension1=array( 60);
$pdf->BasicTable($h1, $res1, $dimension1);





$pdf->Titre2("Balance (-)");
	$h2=array("nombre","Montant");
	$res2=array();
	$r2[]=$this->nbr_negatif();
	$r2[]=$this->mnt_negatif();
	$res2=array();
	$res2[]=$r2;
	$dimension2=array( 60, 60);
$pdf->BasicTable($h2, $res2, $dimension2);



	$h3=$this->champs();
	$res3=$this->liste_negatif();
	if ($res3){
	$pdf->Titre2("Detailles");
	
	$dimension3=array(67, 70, 70, 70);
$pdf->BasicTable($h3, $res3, $dimension3);
}
}
include 'variables.php';

$nom_fichier='b'.$this->num_balance.'_'.$this->moi.'_'.$this->annee.'.pdf';
$uploadpath=$uploadpath."\\".$this->numfact."\\";
$pdf->Output($uploadpath.$nom_fichier,'F');
header("Content-type:application/pdf");
readfile($uploadpath.$nom_fichier);
}

}
?>