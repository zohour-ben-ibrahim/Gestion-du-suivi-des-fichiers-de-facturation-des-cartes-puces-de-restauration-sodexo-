<? 
header("Content-type:application/pdf");
readfile("../../../uploads/rapport.pdf");
?>