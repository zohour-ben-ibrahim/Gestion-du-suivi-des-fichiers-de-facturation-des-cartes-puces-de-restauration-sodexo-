
<?
error_reporting(E_ERROR);
session_start(); 

if (!isset($_SESSION['pseudo'])){

header('location:../index.php');}
else
 {
require_once 't_facture.php';
require_once 'connection.php';
require_once 'excelwriter.inc.php';
require_once 'C:\xampp\phpmyadmin\libraries\zip.lib.php' ; // librairie ZIP

include('variables.php');
	$cnx=new connection();
      $cnx->Connect("");
	 $f=new facture();
$fact=$f->derniere_facture ();	 
	  
$fileName = $uploadpath."\\".$fact[0]."\\Declaration_".$fact[1]."_".$fact[2].".xls";
	$excel = new ExcelWriter($fileName);
	$myArr=array("Matricule",
				"Nom et prenom",
				"Residence",
				"Direction",
				"Montant"
				);

	$excel->writeLine($myArr, array('text-align'=>'center', 'color'=> 'blue', 'font'=>'bold'));

       

	  $residence=$_POST['r']; //récupérer les residences cochées
		foreach ($residence as $r){ 
	$req=$cnx->Select("select f.mat, f.npre, r.lib, d.lib_d, sum(f.mnt) from ".$fact[11]." f, t_direction d, t_residence r,
	t_pers p  where upper (flag)= 'OK' and f.mat = p.mat and p.code_residence = ".$r." and p.code_residence =r.code_residence and  r.code_d=d.code_d group by f.mat, f.npre, r.lib, d.lib_d",false);
	
	
	while($res=$cnx->FetchArray($req)){
      $tab=array ($res[0],$res[1],$res[2],$res[3],$res[4]);
	$excel->writeLine($tab, array('text-align'=>'left', 'color'=> 'black'));
}
	} 
	 
	$excel->close();
	//creation de tableau contenant les residences non cochées
	$tout=array();//contient toutes les residences
	$non_coche=array();//contient les residences non cochées
	$req3=$cnx->Select("select code_residence  from t_residence",false);
	while($res3=$cnx->FetchArray($req3)){$tout[]=$res3[0];}
	foreach ($tout as $t){ 
	$test=true;
	foreach ($residence as $r){
	if($t===$r){
	$test=false;
    break;//pour optimiser le temps de réponce s'il trouve le residence en cour de verification dans la liste cochée il arrete(la boucle) la comparaison
	     //et passe à la residence suivante de tableau tout.
	}}
	if($test){$non_coche[]=$t; }
	}
	//liste complète------------
	
		
	//création de fichier excel contenant les residences non cochées 
    $file2Name = $uploadpath."\\".$fact[0]."\\Astraint_".$fact[1]."_".$fact[2].".xls";
	$excel2 = new ExcelWriter($file2Name);
	
	$excel2->writeLine($myArr, array('text-align'=>'center', 'color'=> 'blue', 'font'=>'bold'));
	
	foreach ($non_coche as $r){ 
	$req2=$cnx->Select("select f.mat, f.npre, r.lib, d.lib_d, sum(f.mnt) from ".$fact[11]." f, t_direction d, t_residence r,
	t_pers p  where upper (flag)= 'OK' and f.mat = p.mat and p.code_residence = ".$r." and p.code_residence =r.code_residence and  r.code_d=d.code_d group by f.mat, f.npre, r.lib, d.lib_d",false);
	
	
	while($res2=$cnx->FetchArray($req2)){
      $tab2=array ($res2[0],$res2[1],$res2[2],$res2[3],$res2[4]);
	$excel2->writeLine($tab2, array('text-align'=>'left', 'color'=> 'black'));
}}

	$excel2->close();
	
	
	
	$cnx->__destruct();
	$nom_zip="declaration_".$fact[1]."_".$fact[2];
	

	
	//affichage_________________________________________________

?>












<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Directions</title>
 
<script language="JavaScript">


window.onload = montre;
function afficheDate()// Notre fonction pour afficher la date et l'heure   
	{

	jour = new Array ("Dim","Lun","Mar","Mer","Jeu","Ven","Sam");
	mois = new Array ("Jan","Fév","Mar","Avr","Mai","Jui","Jul","Aoû","Sep","/10","Nov","Déc");
	date=new Date();

	datejour=date.getDate();
	heure=date.getHours();
	minute=date.getMinutes();
	seconde=date.getSeconds();
	if (date.getDate()<10) datejour="0"+datejour;

	if (heure<10) heure="0"+heure;
	if (minute<10) minute="0"+minute;
	if (seconde<10) seconde="0"+seconde;
	document.getElementById("texteDate").innerHTML=jour[date.getDay()]+"  "+datejour+"   "+mois[date.getMonth()]+" 			"+heure+":"+minute+":"+seconde;
	setTimeout("afficheDate()", 1000);

		}
			

</script>
<script type="text/javascript" src="menu/stmenu.js"></script>


<style>      
#liste thead {      
 display:block;      
}      
#liste tbody {      
 display:block;      
 height:250px; /* 5 times the equivalent of a text "size". */      
 overflow-y:scroll;      
}      

 #liste thead tr th:nth-child(1) { /* column 1 ! */      
  width:380px;      
 }      
 #liste thead tr th:nth-child(2) { /* column 2 */      
  width:380px;      
 }
 
 #liste tbody tr:first-child td:nth-child(1) { /* column 1 ! */      
  width:380px;      
 }      
 #liste tbody tr:first-child td:nth-child(2) { /* column 2 */      
  width:380px;      
 }  
 

</style>   
</head>

<body  onload="afficheDate()" background="bg.jpg"><br /><br /><br /><br />
        
<table width="755" height="544" border="0" align="center" cellpadding="2" cellspacing="0" bgcolor="#0D6DD3" id="t1"    style="border-radius: 50px;box-shadow: 8px 8px 12px #004;">   <tr height="51">
    <td background="banniere.png"><div id ="texteDate" style="font-size:10pt;font-weight:bold;margin-top:135px;"></div></td><td background="banniere.png">	<img src="ban1.gif" width="390" height="152" align="left" onMouseOver="this.src='laposte-tunisie.jpg'" onMouseOut="this.src='ban1.gif'" />
<img src="Sans titre-.png" width="239" height="152" align="right" /></td>
  </tr>
  <tr height="23"><td colspan="2">
	 
	 <script type="text/javascript">
stm_bm(["menu0f4d",980,"","menu/blank.gif",0,"","",1,0,250,0,1000,1,0,0,"","750",67109119,0,1,2,"default","hand","",1,25],this);
stm_bp("p0",[0,4,0,0,0,0,0,0,100,"",-2,"",-2,50,0,0,"#799BD8","transparent","menu/060417line.gif",3,0,0,"#000000","",0,0,0,"transparent","",3,"menu/060417buttona2.gif",26,5,0,"transparent","",3,"",0,0,0,"transparent","",3,"menu/060417buttona1.gif",26,5,0,"transparent","",3,"","","","",20,20,20,20,20,20,20,20]);
stm_ai("p0i0",[0,"Upload","","",-1,-1,0,"","_self","","","","",0,0,0,"","",0,0,0,1,1,"#FFFFF7",1,"#B5BED6",1,"","menu/bg_16.gif",3,3,0,0,"#FFFFF7","#000000","#66FFFF","#000066","bold 7pt Verdana","bold 7pt Verdana",0,0,"","","","",0,0,0],90,26);
stm_bp("p1",[0,4,-2,0,0,0,0,0,100,"progid:DXImageTransform.Microsoft.Fade(overlap=.5,enabled=0,Duration=0.32)",-2,"progid:DXImageTransform.Microsoft.Fade(overlap=.5,enabled=0,Duration=0.32)",-2,78,0,0,"#799BD8","#EEEEEE","menu/060417line1.gif",3,0,0,"#000000"]);
stm_ai("p1i0",[0,"Nouvelle","","",-1,-1,0,"upload.php","_self","","Nouvelle facture","","",0,0,0,"","",0,0,0,1,1,"#FFFFF7",1,"#B5BED6",1,"menu/060417line1.gif","menu/060417line1.gif",3,3,0,0,"#FFFFF7","#000000","#333399","#FF0000","bold 7pt Verdana","bold 7pt Verdana",0,0,"menu/060417line1.gif","menu/060417line1.gif","menu/060417line1.gif","menu/060417line1.gif",10,10,26],65,26);
stm_aix("p1i1","p1i0",[0,"Historique","","",-1,-1,0,"encien.php","_self","","Ancienne facture"],65,26);
stm_ep();
stm_aix("p0i1","p0i0",[0,"Balances","","",-1,-1,0,"","_self","","Balances","","",0,0,0,"","",0,0,0,1,1,"#FFFFF7",1,"#0099CC",0],90,26);
stm_bpx("p2","p1",[0,4,-80]);
stm_aix("p2i0","p1i0",[0,"Balance 1","","",-1,-1,0,"b1.php","_blanc","","Charge poste VS charge SODEXO","","",0,0,0,"","",0,0,0,0],80,26);
stm_aix("p2i1","p2i0",[0,"Balance 2","","",-1,-1,0,"b2.php","_blanc","","Charge Sodexo VS Consommation"],80,26);
stm_aix("p2i2","p2i0",[0,"Balance 3","","",-1,-1,0,"b3.php","_blanc","","Charge poste VS Consommation"],0,26);
stm_aix("p2i3","p2i0",[0,"Récap","","",-1,-1,0,"recap.php","_blanc","","Récap"],0,26);
stm_aix("p2i3","p2i0",[0,"Télécharger balances","","",-1,-1,0,"form_telecharger_balances.php","_self","","Récap"],0,26);
stm_ep();
stm_aix("p0i3","p0i0",[0,"Historique","","",-1,-1,0,"historique.php","_self","","Historique"],90,26);
stm_aix("p0i4","p0i0",[0,"Consultation personnalisée","","",-1,-1,0,"consult.php","_self","","Consultation personnalisée"],90,26);
stm_aix("p0i5","p0i0",[0,"Déclaration","","",-1,-1,0,"declaration.php","_self","","Déclaration"],90,26);
stm_aix("p0i2","p0i0",[0,"Directions","","",-1,-1,0,"residence.php","_self","","Directions","","",0,0,0,"","",0,0,0,1,1,"#FFFFF7",1,"#0066CC"],90,26);
stm_aix("p0i6","p0i0",[0,"Déconnexion","","",-1,-1,0,"logout.php","_self","","Déconnexion"],90,26);
stm_ep();
stm_em();
</script>
	 
	 
	      </td></tr>
		   

		  <tr><td colspan="2"><center>
		<table id="liste"  width="755" height="300" border="0" cellspacing="2" align="center">  		
         <thead>
  <tr ><th bgcolor="#05015D" width="377"><font color="#02ABE2">Déclaration</font></th><th bgcolor="#02ABE2" width="378"><font color="#07017D">Astraint</font></th></tr>

</thead >
 <tbody>
<? 

echo"<tr><td><center>";

header("content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=".$fileName);

flush(); // Envoie le buffer
readfile($fileName); // Envoie le fichier 
echo "</center></td>";	
echo"<td><center>";
fclose($fileName);
header("content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=".$file2Name);

flush(); // Envoie le buffer
readfile($file2Name); // Envoie le fichier 	
echo "</center></td></tr>";
fclose($file2Name);
?>
</tbody>
</table></center>
<center><form action="telecharger_declaration.php" method="POST">
		  <input  type="hidden" name="f1" value= "<? echo $fileName ?>" />
           <input type="hidden" name= "f2" value= "<? echo $file2Name ?>"/>
		   <input type="hidden" name= "f" value= "<? echo $nom_zip ?>"/>
		  <input type="submit" value="Télécharger"></form></center>
</td></tr></table>


</body>
</html>
<?
}	


?>