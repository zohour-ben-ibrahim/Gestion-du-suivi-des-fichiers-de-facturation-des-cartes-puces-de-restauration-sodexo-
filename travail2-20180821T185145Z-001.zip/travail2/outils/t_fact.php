<?php
error_reporting(E_ERROR);
require_once 'connection.php'; 
require_once 't_facture.php'; 
class t_fact{
private $mois;
private $annee;
private $table;
private $numfact;
    

public function __construct($mois, $annee, $numfact,$table)                                       
    { $this->numfact = $numfact;
      $this->mois = $mois;
	  $this->annee = $annee;
	  $this->table = $table;
    }

public function insertion ($champs)
	{
	 $cnx=new connection();
      $cnx->Connect("");

   $req=$cnx->Insert($this->table, &$champs, false, false);
    $cnx->Commit(); 
   $cnx->__destruct();
   
	}	
	
	public function valider_transact()
	{$cnx=new connection();
      $cnx->Connect("");
	  $req=$cnx->Select("select id_tr,mat from ".$this->table,false);
	   
	  while($res=$cnx->FetchArray($req)) {
	  $id_tr=$res[0];
	  $mat=$res[1];
		$rq="";
	 $t=array();
	 $test=true;
	 $t2=array();
		$f=new facture();
		
		$fact=$f->getfacture_mois($this->annee,$this->mois);
	 $req2=$cnx->Select("select MAT from ".$fact[9]." where ID_TR = :i",array (":i"=>$id_tr));
	
	while($res2=$cnx->FetchArray($req2)){
	//remarque
	if(!$res2){//s'il n'existe pas  une transaction ayant le mem ID
	$test=false;
	 $rq="ID_TR";
	}
	else{
	    if($res2[0] != $mat){
			//ya des agents avec 2 matricules et parfois sodexo n'utilise pas le mem  mat dans le fichier conso et facture malgré qu la transaction appartient au mem agent
            //si le matricule est erroné on vérifie si c l'autre matricule de mem agent est utilisé
			$req3=$cnx->Select("select MAT from t_pers where mat <> ".$mat." and cin in (select cin from t_pers where mat= ".$mat.")" ,false);
			$i=-1;
			$test2=false;
	        while($res3=$cnx->FetchArray($req3)){
			$i=$i+1;
			if($res3[0]===$res2[0]){
			$test2=true;
			break;}
			}
	       if(! $test2){ // c-à-d que le matricule est vraiment erroné et n'appartient pas a cet agent
	             $rq=$rq."mat";
	             $test=false;}
	
	            }
	    }
	}
	
	
	
	
	  if($test)
	  $t['flag']="'OK'";
	  else{
	  $t['flag']="'Non'";
	   $t['rq']="'".$rq."'"; }  
		  $condition="id_tr = '".$id_tr."'";
	     $r1=$cnx->Update($this->table,&$t,$condition,false,false);
		 //la table conso ne contient pas le champ RQ alors on ne doit inserer que flag dans tt les cas
		 
		 $t2['flag']=$t['flag'];
		 
		 $r2=$cnx->Update($fact[9],&$t2,$condition,false,false);
	  
	  }

$cnx->Commit(); 
   $cnx->__destruct();
	}
	
	
	
	function verif_mnt(){
	$cnx=new connection();
      $cnx->Connect("");
	  $f=new facture();
		$fact=$f->getfacture_mois($this->annee,$this->mois);
	    $req=$cnx->Select("select sum(mnt) from ".$this->table." where upper(flag) = 'OK'",false);
		$som_fact=0;
	  while($res=$cnx->FetchArray($req)) {
	  if ($res[0] != null){
	  $som_fact=$res[0];}
	  }
	  $cnx->Commit(); 
   $cnx->__destruct();
	

	  if((float)$som_fact === (float)$fact[3])
	  return true;
	  else
	  return false;
	  
	}
	}
	?>