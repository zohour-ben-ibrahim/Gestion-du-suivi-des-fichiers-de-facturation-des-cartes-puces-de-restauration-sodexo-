<?php
error_reporting(E_ERROR);

require_once'pdf.php';
require_once'variables.php';
require_once't_facture.php';
$mois=$_POST['mois'];
$annee=$_POST['annee'];
$fact=new facture();
$f=$fact->getfacture_mois($annee,$mois);
$numfact=$f[0];
$uploadpath=$uploadpath.$numfact."\\";
$nom_fichier=$uploadpath."Rapport_".$mois."_".$annee.".pdf";
if (file_exists($nom_fichier)) {
header("Content-type:application/pdf");
 readfile($nom_fichier);
} else {
include 'encien.php';
 ?>
<script = "javascript"> alert ("Cette facture n\'existe pas dans la base")</script>;
<?php
}
?>