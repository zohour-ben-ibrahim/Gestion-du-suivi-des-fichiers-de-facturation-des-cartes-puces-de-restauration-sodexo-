<?php
error_reporting(E_ERROR);
require_once 'connection.php'; 
class t_conso{

private $mois;
private $annee;
private $montant;
private $table;
private $numfact;


public function __construct($mois, $annee,$montant, $numfact,$table)                                       
    { $this->numfact = $numfact;
      $this->mois = $mois;
	  $this->montant=$montant;
	  $this->annee = $annee;
	  $this->table = $table;
    }
	
	public function suppression ()
	{
	 $cnx=new connection();
      $cnx->Connect(""); 
   $init=$cnx->Delete($this->table, false, false, false);//supprimer l'encien contenu de la table
   $cnx->__destruct();
	}
	
	
public function insertion ($champs)
	{
	 $cnx=new connection();
      $cnx->Connect("");

   $req=$cnx->Insert($this->table, &$champs, false, false);
       $cnx->Commit(); 
   $cnx->__destruct();

	}
	


	public function verif_identite(){//parcourir toute la table  t_conso en verifiant matricule et CIN par rapport a la table t_pers 
	$cnx=new connection();
      $cnx->Connect("");
	 $r=false;
	 $t=array();
	  $req=$cnx->Select("select id_tr,mat,npre,cin from ".$this->table,false);
	while($res=$cnx->FetchArray($req)) {
	$mat=$res[1];
	$npre=$res[2];
	$cin=$res[3];
		
	 $req2=$cnx->Select("select MAT from t_pers where MAT = :m and CIN = :c",array (":m"=>$mat,":c"=>$cin));
	 $x=0;
	while($res2=$cnx->FetchArray($req2)){
	$x=$x+1;}
	
	if($x === 0){
	//cette transaction contient des erreurs
    $t[]=$res;
	$r=true;
	}
	}
	$cnx->__destruct();
	if ($r)
	return $t;
	else return $r;
}

public function plusieur_carte(){ //agents ayant ++ cartes
	$cnx=new connection();
      $cnx->Connect("");
	 $r=0;
	  $req=$cnx->Select("select mat,count(distinct n_carte) from ".$this->table." group by mat having count(distinct n_carte)>1",false);
	  $re=array();
	while($res=$cnx->FetchArray($req)){
	$ch="";
	 $req2=$cnx->Select("select distinct n_carte from ".$this->table." where mat=".$res[0],false);
	while($res2=$cnx->FetchArray($req2)){$ch=$ch.$res2[0]." || ";}
	$r=$r+1;
$r2=array($res[0],$res[1],$ch);	
	$re[]=$r2;
	}
	$cnx->__destruct();
	if ($r===0)
	         return false;
	else{return $re;}
}



public function verif_carte (){//verifier si il y"a une carte appartient au plusieurs porteurs

$cnx=new connection();
      $cnx->Connect("");
	 $r=0;
	 $re=array();
	  $req=$cnx->Select("select n_carte,count(distinct mat) from  ".$this->table."  group by n_carte having count(distinct mat)>1",false);
	while($res=$cnx->FetchArray($req)){
	$r=$r+1;	
	$re[]=$res;
	}
	$cnx->__destruct();
	if ($r===0)
	return false;
	else{
	return $re;
	
	}
}

	
	
	public function verif_montant ()
	{ $cnx=new connection();
      $cnx->Connect("");
	  $req=$cnx->Select("select sum(mnt) from ".$this->table." where upper(type)='ACHAT'",false);
	   
	while($res=$cnx->FetchArray($req)){
	$som_achat=str_replace(',','.',$res[0]);
	
	}
	
	 $req2=$cnx->Select("select sum(mnt) from ".$this->table." where upper(type)='ANNULATION'",false);
	while($res2=$cnx->FetchArray($req2)){
	$som_annul=str_replace(',','.',$res2[0]);
	
	}
	$cnx->__destruct();
	$som_mnt=$som_achat-$som_annul;
	$mnt=str_replace(',','.',$this->montant);

	if((string)$som_mnt === (string)$mnt){
	return false;

	}
	else
	return $som_mnt;
	

	}
	

public function verif_id_tr ()//verifier si un id_tr existe déja dans t_global_aaaa
{$re=array();
$cnx=new connection();
      $cnx->Connect("");
	$req1=$cnx->Select("select t_global from t_facture where t_conso= :t ",array(":t"=>$this->table));
	while($res1=$cnx->FetchArray($req1)){$y=$res1[0]; }
  $req=$cnx->Select("select id_tr from ".$this->table." where  id_tr in (select id_tr from ".$y.")",false);
	$x=0;
	
	while($res=$cnx->FetchArray($req)){
	$x=$x+1;
	$re[]=$res[0];}
	$cnx->__destruct();
	if($x === 0){
	return false;}//tt va b1
	else{
	return $re;

	}//redendance de id_tr
}

public function supprimer()
{
$req="drop table ".$this->table;

$cnx=new connection();
$cnx->Connect(""); 
$x=$cnx->execute($req,false);
$cnx->__destruct();
}
	
	
public function SelectAll (){

 $cnx=new connection();
      $cnx->Connect("");
	  $req=$cnx->Select("select * from ".$this->table);
	
	$cnx->__destruct();
	return $req;
}	
	
	
}
?>