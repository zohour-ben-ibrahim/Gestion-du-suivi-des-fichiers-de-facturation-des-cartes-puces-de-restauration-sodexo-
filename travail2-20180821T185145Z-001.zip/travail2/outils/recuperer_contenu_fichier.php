<?php
error_reporting(E_ERROR);
ini_set("memory_limit","-1");
session_start(); 
require_once 't_global.php';
require_once 't_facture.php';
require_once 'class_nouveau_table.php';
require_once('pdf.php');
require_once 't_conso.php';
require_once 'C:\xampp\PHPExcel\Classes\PHPExcel\IOFactory.php';
require_once 'C:\xampp\PHPExcel\Classes\PHPExcel\Autoloader.php'; 
require_once 'variables.php';
//récupérer les variables de formulaire
 $m=$_POST['mois'];
 $a=$_POST['annee'];
 $mnt=$_POST['montant'];
 $num=$_POST['numfact'];
 
//On crée une variable contenant le répertoire de destination 
$uploadpath=$uploadpath.$num."\\";
//creation de repertoire
if(! is_dir ($uploadpath)){
mkdir($uploadpath);}
$f=new facture($m,$a,$mnt,$num,$uploadpath);
$balance=$f->balance_non_calculee ();
if((!$f->existe()) && ($f->mois_precident_inexistant()) && (!$balance)){
$f->insertion();
$path=$f->getFichier();
//On déplace le fichier du dossier temporaire vers le dossier de destination 
 $tmp_name=$_FILES['fichier']['tmp_name'];
move_uploaded_file($tmp_name,$path); 
// Chargement du fichier Excel
$objPHPExcel = PHPExcel_IOFactory::load($path);
/**
* récupération de la première feuille du fichier Excel
* @var PHPExcel_Worksheet $sheet
*/
$conso=$f->getConso();
$t= new t_conso($m, $a, $mnt, $num,$conso);


$sheet = $objPHPExcel->getSheet(0);
$i=-1;
// On boucle sur les lignes
foreach($sheet->getRowIterator() as $row) {
   $i=$i+1;
   if($i!=0){
   $j=-1;
   $tab=array();
   // On boucle sur les cellule de la ligne
   foreach ($row->getCellIterator() as $cell) {
      $j=$j+1;
      $x=$cell->getValue();
	  switch ($j) {
    case 0: $tab['id_tr']="'".$x."'";
	break;
	case 1: $tab['mat']="'".$x."'";
	 break;
    case 2: $tab['cin']=$x;
	break;	 
    case 3: $tab['n_carte']="'".$x."'";
	break;
	case 4: $tab['npre']="'".$x."'"; 
	break;
	case 5:$x=str_replace(',','.',$x);
	$tab['mnt']=$x;
	break;
	case 6:$x=str_replace('\'',' ',$x);// quelques affilié leus libelle contiennent de (')
	$tab['aff']="'".$x."'";
	break;
	case 7: $tab['date_tr']="'".$x."'";
	break;
	case 8: $tab['type']="'".$x."'";
	break;
     } 
   }
   $t->insertion($tab);

}} 

$v_carte= $t->verif_carte();
$v_pluscarte=$t->plusieur_carte();
$v_ident= $t->verif_identite();
$v_id_tr=$t->verif_id_tr(); 
$table=$f->getGlobal();
// if(!$v_carte && !$v_ident && !$v_id_tr)
// {
//insertion dans t_global

$t_glob= new t_global($table);
$req=$t->SelectAll();
$cnx=new connection();
      $cnx->Connect("");
$cnx->SetFetchMode(OCI_ASSOC);
$champs=array();
while($res=$cnx->FetchArray($req)){
$champs['mois']=$m;
$champs['ID_TR']="'".$res[0]."'" ;
$champs['MAT']="'".$res[1]."'" ;  
$champs['CIN']=$res[2] ;
$champs['N_CARTE']="'".$res[3]."'" ;
$champs['NPRE']="'".$res[4]."'" ;
$montant=str_replace(',','.',$res[5]);
$champs['MNT']=$montant;
$champs['AFF']="'".$res[6]."'" ;
$champs['DATE_TR']=" to_date('".$res[7]."', 'DD-MM-YYYY HH24:MI:SS')";
$champs['type']="'".$res[8]."'" ;
$t_glob->insertion($champs);
}
$cnx->__destruct();



//_____________________________________________________________________________________
//creation de rapport



$pdf = new PDF();

$x='Rapport de facture: '.$num;
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->Titre($x);

//	mem carte avec + porteurs--------------
if($v_carte){ 
$pdf->Titre2("les numeros de cartes suivants appartiennent au plusieurs porteurs");
	$h=array("Numero de carte","Nombre de porteurs");
	$dimension=array( 60, 60);
$pdf->BasicTable($h, $v_carte, $dimension);
}

//porteurs de + cartes----------------

if($v_pluscarte){
$pdf->Titre2("ceux qui ont plus qu'une carte");
	$h=array("Matricule","Nombre de cartes","cartes");
	$dimension=array( 50, 50, 90);
$pdf->BasicTable($h, $v_pluscarte, $dimension);
}

//identités erronées----------------

if($v_ident){//cette fonction retourne un tableau multidimension

$pdf->Titre2("Les transactions suivantes ont besoin de vérification");
	$h=array("ID de transaction","Matricule","Nom et prénom","CIN");
	
	
	$dimension=array(37, 37, 79,37);
$pdf->BasicTable($h, $v_ident, $dimension);
}


//Redendance de ID de transaction----------------

if($v_id_tr){
$tab="Les ID transactions suivantes éxiste déja dans  ".$table;
  $pdf->Titre2($tab);

foreach($v_id_tr  as $cel){
  $pdf->Ln(2);
	$pdf->Cell(0,10,'- '.$cel,0,1);
	
    }}

if(!$v_carte && !$v_ident && !$v_id_tr)
  
{$pdf->Titre2('                        auccune erreur détectée');
}
// else
// {$t->supprimer();
// $f->suprimer_facture($num);

// }
$nom_fichier='Rapport_'.$m.'_'.$a.'.pdf';
$pdf->Output($uploadpath.$nom_fichier,'F');
header("Content-type:application/pdf");
readfile($uploadpath.$nom_fichier);


//______________________________________________________________________________________________________________________
}
else{if($balance){
include('upload.php');

	  echo"<script language='javascript'>alert(' vouillez calculer les balances du mois ".$balance." avant de continuer ! ');</script>";
	
 }
 

else  if(!$moi_prec){
include('upload.php');
$m_prec=$m-1;
	  echo"<script language='javascript'>alert(' la facture du mois ".$m_prec." n\'est pas encore traitée! ');</script>";


}
else {if($existe)
include('upload.php');
	 echo"<script language='javascript'>alert(' Cette facture existe déja ! ');</script>";

}

}




?>

  
