<?php
require('pdf.php');
$pdf = new PDF();

$x='Rapport de facture: '.$num;
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->Titre($x);

	
//	mem carte avec plusieur porteurs--------------
if($v_carte){
$pdf->Titre2("les numeros de cartes suivants appartiennent au plusieurs porteurs");
	$h=array("Numero de carte","Nombre de porteurs");
	$d=array();
	while($res=oci_fetch_array($v_carte))
	{$d[]=$res;}
	$dimension=array( 60, 60);
$pdf->BasicTable($h, $d, $dimension);
}

//porteurs de plusieur cartes----------------

if($v_pluscarte){
$pdf->Titre2("ceux qui ont plus q\'une carte");
	$h=array("Matricule","Nombre de cartes");
	$d=array();
	while($res=oci_fetch_array($v_pluscarte))
	{$d[]=$res;}
	$dimension=array( 60, 60);
$pdf->BasicTable($h, $d, $dimension);
}

//identités erronées----------------

if($v_ident){//cette fonction retourne un tableau multidimension
$pdf->Titre2("Les transactions suivantes ont besoin de vérification");
	$h=array("ID de transaction","Matricule","Nom et prénom","CIN");
	
	
	$dimension=array(37, 37, 79,37);
$pdf->BasicTable($h, $v_ident, $dimension);
}


//Redendance de ID de transaction----------------

if($v_id_tr){
$pdf->Titre2("Les ID de transaction suivantes existent déja vouillez les changer");
	while($res=oci_fetch_array($v_id_tr))
	{$d=$res[0];
	$pdf->Cell(0,10,'- '.$d,0,1);
    }
}
if(!$v_mnt && !$v_carte && !$v_ident && !$v_id_tr)
{$pdf->Cell(0,10,'                                                                          auccune erreur détectée',0,1);
}

$pdf->Output();
?>