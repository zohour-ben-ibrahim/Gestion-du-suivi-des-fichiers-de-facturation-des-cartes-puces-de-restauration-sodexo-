<?php
error_reporting(E_ERROR);
require_once 'connection.php'; 
class t_global{
private $table;



public function __construct($table)                                       
    {
	  $this->table = $table;
    }

public function insertion ($champs)
	{
	 $cnx=new connection();
      $cnx->Connect("");

   $req=$cnx->Insert($this->table, &$champs, false, false);
   $cnx->__destruct();
    $cnx->Commit(); 
	}

}

?>